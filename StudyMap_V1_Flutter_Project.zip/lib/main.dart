import 'dart:async';
import 'package:flutter/material.dart';

void main() => runApp(const StudyMapApp());

class StudyMapApp extends StatelessWidget {
  const StudyMapApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'StudyMap',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
        scaffoldBackgroundColor: const Color(0xFFF7F8FC),
      ),
      home: const AppShell(),
    );
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int index = 0;
  final tasks = <StudyTask>[
    StudyTask('Political Science', 'Constitution chapter revise', 45),
    StudyTask('History', 'Practice 20 MCQs', 30),
    StudyTask('Economics', 'Read and make short notes', 40),
  ];

  void addTask() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => AddTaskSheet(onAdd: (task) {
        setState(() => tasks.add(task));
        Navigator.pop(context);
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(tasks: tasks, onChanged: () => setState(() {}), onAdd: addTask),
      PlannerPage(tasks: tasks, onChanged: () => setState(() {}), onAdd: addTask),
      const RescuePage(),
      const ProgressPage(),
      const ProfilePage(),
    ];

    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.map_outlined), selectedIcon: Icon(Icons.map), label: 'Plan'),
          NavigationDestination(icon: Icon(Icons.health_and_safety_outlined), selectedIcon: Icon(Icons.health_and_safety), label: 'Rescue'),
          NavigationDestination(icon: Icon(Icons.bar_chart_outlined), selectedIcon: Icon(Icons.bar_chart), label: 'Progress'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class StudyTask {
  StudyTask(this.subject, this.title, this.minutes, {this.done = false});
  final String subject;
  final String title;
  final int minutes;
  bool done;
}

class HomePage extends StatelessWidget {
  const HomePage({super.key, required this.tasks, required this.onChanged, required this.onAdd});
  final List<StudyTask> tasks;
  final VoidCallback onChanged;
  final VoidCallback onAdd;

  @override
  Widget build(BuildContext context) {
    final done = tasks.where((t) => t.done).length;
    final progress = tasks.isEmpty ? 0.0 : done / tasks.length;
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Good Evening 👋', style: TextStyle(fontSize: 16)),
        const SizedBox(height: 4),
        const Text('Welcome to StudyMap', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
        const SizedBox(height: 20),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Today’s Progress', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
              const SizedBox(height: 12),
              LinearProgressIndicator(value: progress, minHeight: 10, borderRadius: BorderRadius.circular(10)),
              const SizedBox(height: 10),
              Text('$done of ${tasks.length} tasks completed • ${(progress * 100).round()}%'),
            ]),
          ),
        ),
        const SizedBox(height: 18),
        const Text('Today’s Plan', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        ...tasks.map((t) => Card(
          child: CheckboxListTile(
            value: t.done,
            onChanged: (v) { t.done = v ?? false; onChanged(); },
            title: Text(t.title),
            subtitle: Text('${t.subject} • ${t.minutes} min'),
          ),
        )),
        const SizedBox(height: 8),
        FilledButton.icon(onPressed: onAdd, icon: const Icon(Icons.add), label: const Text('Add Study Task')),
        const SizedBox(height: 20),
        const FocusTimer(),
      ],
    );
  }
}

class PlannerPage extends StatelessWidget {
  const PlannerPage({super.key, required this.tasks, required this.onChanged, required this.onAdd});
  final List<StudyTask> tasks;
  final VoidCallback onChanged;
  final VoidCallback onAdd;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Study Roadmap 🗺️', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Plan your subjects, chapters and daily targets.'),
        const SizedBox(height: 18),
        ...tasks.asMap().entries.map((entry) {
          final t = entry.value;
          return Card(
            child: ListTile(
              leading: CircleAvatar(child: Text('${entry.key + 1}')),
              title: Text(t.title),
              subtitle: Text(t.subject),
              trailing: Text('${t.minutes}m'),
              onTap: () { t.done = !t.done; onChanged(); },
            ),
          );
        }),
        const SizedBox(height: 12),
        FilledButton.icon(onPressed: onAdd, icon: const Icon(Icons.add), label: const Text('Create New Task')),
      ],
    );
  }
}

class RescuePage extends StatefulWidget {
  const RescuePage({super.key});
  @override
  State<RescuePage> createState() => _RescuePageState();
}

class _RescuePageState extends State<RescuePage> {
  double missedDays = 3;
  double hours = 4;

  @override
  Widget build(BuildContext context) {
    final recoveryTasks = (missedDays * 2 / hours).ceil().clamp(1, 8);
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Study Rescue 🆘', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Don’t restart. Recover. Create a realistic plan after missed study days.'),
        const SizedBox(height: 24),
        Text('Missed study days: ${missedDays.round()}'),
        Slider(value: missedDays, min: 1, max: 30, divisions: 29, onChanged: (v) => setState(() => missedDays = v)),
        Text('Available study hours/day: ${hours.round()}'),
        Slider(value: hours, min: 1, max: 12, divisions: 11, onChanged: (v) => setState(() => hours = v)),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Your Recovery Plan', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
              const SizedBox(height: 12),
              Text('Day 1: $recoveryTasks priority tasks'),
              Text('Day 2: $recoveryTasks priority tasks + revision'),
              const Text('Day 3: Light revision + practice test'),
              const SizedBox(height: 10),
              const Text('Goal: Gradually return to your normal schedule.', style: TextStyle(fontWeight: FontWeight.w500)),
            ]),
          ),
        ),
      ],
    );
  }
}

class ProgressPage extends StatelessWidget {
  const ProgressPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      const Text('Progress 📊', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
      const SizedBox(height: 20),
      _stat('Study Streak', '7 Days 🔥'),
      _stat('This Week', '12h 40m'),
      _stat('Completed Tasks', '18'),
      _stat('Exam Readiness', 'Coming soon'),
    ],
  );

  Widget _stat(String title, String value) => Card(
    child: ListTile(title: Text(title), trailing: Text(value, style: const TextStyle(fontWeight: FontWeight.bold))),
  );
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: const [
      CircleAvatar(radius: 40, child: Icon(Icons.person, size: 40)),
      SizedBox(height: 16),
      Center(child: Text('Student Profile', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold))),
      SizedBox(height: 20),
      ListTile(leading: Icon(Icons.school), title: Text('Class / Exam'), subtitle: Text('Set during onboarding')),
      ListTile(leading: Icon(Icons.language), title: Text('Language'), subtitle: Text('Hinglish')),
      ListTile(leading: Icon(Icons.dark_mode_outlined), title: Text('Appearance'), subtitle: Text('Light mode')),
    ],
  );
}

class FocusTimer extends StatefulWidget {
  const FocusTimer({super.key});
  @override
  State<FocusTimer> createState() => _FocusTimerState();
}

class _FocusTimerState extends State<FocusTimer> {
  int seconds = 25 * 60;
  Timer? timer;
  bool running = false;

  void toggle() {
    if (running) {
      timer?.cancel();
      setState(() => running = false);
    } else {
      setState(() => running = true);
      timer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (seconds <= 0) {
          timer?.cancel();
          setState(() => running = false);
        } else {
          setState(() => seconds--);
        }
      });
    }
  }

  @override
  void dispose() { timer?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final m = (seconds ~/ 60).toString().padLeft(2, '0');
    final s = (seconds % 60).toString().padLeft(2, '0');
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(children: [
          const Text('Focus Timer ⏱️', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
          const SizedBox(height: 10),
          Text('$m:$s', style: const TextStyle(fontSize: 42, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          FilledButton(onPressed: toggle, child: Text(running ? 'Pause' : 'Start Focus')),
        ]),
      ),
    );
  }
}

class AddTaskSheet extends StatefulWidget {
  const AddTaskSheet({super.key, required this.onAdd});
  final ValueChanged<StudyTask> onAdd;
  @override
  State<AddTaskSheet> createState() => _AddTaskSheetState();
}

class _AddTaskSheetState extends State<AddTaskSheet> {
  final subject = TextEditingController();
  final title = TextEditingController();
  final minutes = TextEditingController(text: '30');

  @override
  void dispose() { subject.dispose(); title.dispose(); minutes.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Padding(
    padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(context).viewInsets.bottom + 20),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      const Text('Add Study Task', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      TextField(controller: subject, decoration: const InputDecoration(labelText: 'Subject')),
      TextField(controller: title, decoration: const InputDecoration(labelText: 'Task / Chapter')),
      TextField(controller: minutes, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Minutes')),
      const SizedBox(height: 16),
      FilledButton(
        onPressed: () {
          if (subject.text.trim().isEmpty || title.text.trim().isEmpty) return;
          widget.onAdd(StudyTask(subject.text.trim(), title.text.trim(), int.tryParse(minutes.text) ?? 30));
        },
        child: const Text('Save Task'),
      ),
    ]),
  );
}
