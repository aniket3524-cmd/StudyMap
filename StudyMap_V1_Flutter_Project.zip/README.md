# StudyMap V1

A Flutter starter project for StudyMap.

## Included
- Home dashboard
- Study task planner
- Focus timer
- Study Rescue Mode
- Progress screen
- Professional Material 3 UI

## Run
1. Install Flutter SDK.
2. Run `flutter pub get`
3. Run `flutter run`

This is Version 1. Firebase, login, notifications, syllabus data, JEE/NEET/CUET/CLAT modules and AI assistant can be added next.
