import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const StudyMapApp());
}

class StudyMapApp extends StatelessWidget {
  const StudyMapApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner:false,
    title:'StudyMap',
    theme:ThemeData(useMaterial3:true,colorSchemeSeed:Colors.indigo),
    home:const AuthGate(),
  );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<User?>(
    stream:FirebaseAuth.instance.authStateChanges(),
    builder:(context,snapshot){
      if(snapshot.connectionState==ConnectionState.waiting){
        return const Scaffold(body:Center(child:CircularProgressIndicator()));
      }
      return snapshot.hasData ? const HomeScreen() : const WelcomeScreen();
    },
  );
}

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});
  @override
  Widget build(BuildContext context)=>Scaffold(
    body:Center(child:Padding(
      padding:const EdgeInsets.all(24),
      child:Column(mainAxisSize:MainAxisSize.min,children:[
        const Icon(Icons.map_outlined,size:90),
        const SizedBox(height:20),
        const Text('StudyMap',style:TextStyle(fontSize:38,fontWeight:FontWeight.bold)),
        const SizedBox(height:10),
        const Text('Your smart study planning app'),
        const SizedBox(height:30),
        FilledButton(
          onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const LoginScreen())),
          child:const Text('Login')),
        TextButton(
          onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const SignupScreen())),
          child:const Text('Create Account')),
      ]),
    )),
  );
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override State<LoginScreen> createState()=>_LoginScreenState();
}
class _LoginScreenState extends State<LoginScreen>{
  final email=TextEditingController(),password=TextEditingController();
  bool loading=false;
  Future<void> login()async{
    setState(()=>loading=true);
    try{
      await FirebaseAuth.instance.signInWithEmailAndPassword(email:email.text.trim(),password:password.text);
      if(mounted)Navigator.popUntil(context,(r)=>r.isFirst);
    }on FirebaseAuthException catch(e){
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.message??'Login failed')));
    }finally{if(mounted)setState(()=>loading=false);}
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(),
    body:ListView(padding:const EdgeInsets.all(24),children:[
      const Text('Login',style:TextStyle(fontSize:30,fontWeight:FontWeight.bold)),
      const SizedBox(height:24),
      TextField(controller:email,decoration:const InputDecoration(labelText:'Email',border:OutlineInputBorder())),
      const SizedBox(height:14),
      TextField(controller:password,obscureText:true,decoration:const InputDecoration(labelText:'Password',border:OutlineInputBorder())),
      const SizedBox(height:20),
      FilledButton(onPressed:loading?null:login,child:Text(loading?'Please wait...':'Login')),
    ]),
  );
}

class SignupScreen extends StatefulWidget{
  const SignupScreen({super.key});
  @override State<SignupScreen> createState()=>_SignupScreenState();
}
class _SignupScreenState extends State<SignupScreen>{
  final name=TextEditingController(),email=TextEditingController(),password=TextEditingController();
  bool loading=false;
  Future<void> signup()async{
    setState(()=>loading=true);
    try{
      final c=await FirebaseAuth.instance.createUserWithEmailAndPassword(email:email.text.trim(),password:password.text);
      await FirebaseFirestore.instance.collection('users').doc(c.user!.uid).set({
        'name':name.text.trim(),'email':email.text.trim(),'createdAt':FieldValue.serverTimestamp()
      });
      if(mounted)Navigator.popUntil(context,(r)=>r.isFirst);
    }on FirebaseAuthException catch(e){
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.message??'Signup failed')));
    }finally{if(mounted)setState(()=>loading=false);}
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(),
    body:ListView(padding:const EdgeInsets.all(24),children:[
      const Text('Create Account',style:TextStyle(fontSize:30,fontWeight:FontWeight.bold)),
      const SizedBox(height:24),
      TextField(controller:name,decoration:const InputDecoration(labelText:'Full Name',border:OutlineInputBorder())),
      const SizedBox(height:14),
      TextField(controller:email,decoration:const InputDecoration(labelText:'Email',border:OutlineInputBorder())),
      const SizedBox(height:14),
      TextField(controller:password,obscureText:true,decoration:const InputDecoration(labelText:'Password (minimum 6 characters)',border:OutlineInputBorder())),
      const SizedBox(height:20),
      FilledButton(onPressed:loading?null:signup,child:Text(loading?'Please wait...':'Create Account')),
    ]),
  );
}

class HomeScreen extends StatelessWidget{
  const HomeScreen({super.key});
  @override Widget build(BuildContext context){
    final user=FirebaseAuth.instance.currentUser!;
    return Scaffold(
      appBar:AppBar(title:const Text('StudyMap'),actions:[
        IconButton(onPressed:()=>FirebaseAuth.instance.signOut(),icon:const Icon(Icons.logout))
      ]),
      body:StreamBuilder<DocumentSnapshot<Map<String,dynamic>>>(
        stream:FirebaseFirestore.instance.collection('users').doc(user.uid).snapshots(),
        builder:(context,s){
          final data=s.data?.data();
          final name=data?['name']??'Student';
          return ListView(padding:const EdgeInsets.all(20),children:[
            Text('Hello, $name 👋',style:const TextStyle(fontSize:28,fontWeight:FontWeight.bold)),
            const SizedBox(height:8),Text(user.email??''),
            const SizedBox(height:25),
            const Card(child:ListTile(leading:Icon(Icons.menu_book_outlined),title:Text('Auto Syllabus'))),
            const Card(child:ListTile(leading:Icon(Icons.map_outlined),title:Text('Smart Roadmap'))),
            const Card(child:ListTile(leading:Icon(Icons.calendar_month_outlined),title:Text('Smart Timetable'))),
            const Card(child:ListTile(leading:Icon(Icons.bar_chart_outlined),title:Text('Progress'))),
          ]);
        },
      ),
    );
  }
}
