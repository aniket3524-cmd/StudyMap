# StudyMap Final Merge V2

Firebase base version.

IMPORTANT:
This package contains Flutter source code and the expected Firebase folder location.

Put your downloaded file here:
android/app/google-services.json

Do not upload google-services.json to a public GitHub repository.

For a complete Android platform project, open this folder in a proper Flutter development environment and run:
flutter create .
flutter pub get
flutterfire configure
flutter run
