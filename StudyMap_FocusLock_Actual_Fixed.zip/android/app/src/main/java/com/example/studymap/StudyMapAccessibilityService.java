package com.example.studymap;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import java.util.Set;

public class StudyMapAccessibilityService extends AccessibilityService {
  private static final String PREFS = "studymap_focus_lock";
  private long lastRedirect = 0;
  @Override public void onAccessibilityEvent(AccessibilityEvent event) {
    if (event == null || event.getPackageName() == null) return;
    String pkg = event.getPackageName().toString();
    if (pkg.equals(getPackageName())) return;
    android.content.SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
    long until = p.getLong("until", 0);
    if (until <= System.currentTimeMillis()) return;
    Set<String> blocked = p.getStringSet("packages", java.util.Collections.emptySet());
    if (!blocked.contains(pkg)) return;
    long now = System.currentTimeMillis();
    if (now - lastRedirect < 1200) return;
    lastRedirect = now;
    Intent i = new Intent(this, MainActivity.class);
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
    startActivity(i);
  }
  @Override public void onInterrupt() {}
  @Override protected void onServiceConnected() {
    super.onServiceConnected();
    android.accessibilityservice.AccessibilityServiceInfo info = new android.accessibilityservice.AccessibilityServiceInfo();
    info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED | AccessibilityEvent.TYPE_WINDOWS_CHANGED;
    info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
    info.flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS;
    setServiceInfo(info);
  }
}
