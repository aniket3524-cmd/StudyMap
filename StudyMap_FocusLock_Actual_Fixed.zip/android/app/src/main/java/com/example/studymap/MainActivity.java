package com.example.studymap;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.accessibility.AccessibilityEvent;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;

public class MainActivity extends FlutterActivity {
  private static final String CHANNEL = "studymap/focus_lock";
  private static final String PREFS = "studymap_focus_lock";
  @Override public void configureFlutterEngine(FlutterEngine flutterEngine) {
    super.configureFlutterEngine(flutterEngine);
    new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), CHANNEL).setMethodCallHandler((call, result) -> {
      if (call.method.equals("openAccessibilitySettings")) {
        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); result.success(null);
      } else if (call.method.equals("isAccessibilityEnabled")) {
        result.success(isServiceEnabled(this));
      } else if (call.method.equals("startLock")) {
        java.util.List<String> pkgs = call.argument("packages"); Integer mins = call.argument("minutes");
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putStringSet("packages", new HashSet<>(pkgs)).putLong("until", System.currentTimeMillis()+mins*60_000L).apply();
        result.success(null);
      } else if (call.method.equals("stopLock")) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putLong("until", 0).apply(); result.success(null);
      } else result.notImplemented();
    });
  }
  static boolean isServiceEnabled(Context c) {
    String enabled = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
    return enabled != null && enabled.toLowerCase().contains(c.getPackageName().toLowerCase());
  }
}
