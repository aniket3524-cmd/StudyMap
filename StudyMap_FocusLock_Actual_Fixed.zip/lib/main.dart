import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/services.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const StudyMapApp());
}

class FocusLockNative {
  static const MethodChannel _channel = MethodChannel('studymap/focus_lock');
  static Future<void> openAccessibilitySettings() async {
    await _channel.invokeMethod('openAccessibilitySettings');
  }
  static Future<bool> isAccessibilityEnabled() async {
    return (await _channel.invokeMethod('isAccessibilityEnabled') as bool?) ?? false;
  }
  static Future<void> startLock({required List<String> packages, required int minutes}) async {
    await _channel.invokeMethod('startLock', {'packages': packages, 'minutes': minutes});
  }
  static Future<void> stopLock() async {
    await _channel.invokeMethod('stopLock');
  }
}

class StudentProfile {
  String name;
  int schoolClass;
  String? stream;
  List<String> goals;
  List<String> selectedSubjects;
  StudentProfile({required this.name, required this.schoolClass, this.stream, required this.goals, List<String>? selectedSubjects}) : selectedSubjects = selectedSubjects ?? [];
  factory StudentProfile.fromMap(Map<String, dynamic> d) => StudentProfile(
    name: (d['name'] ?? 'Student').toString(),
    schoolClass: (d['schoolClass'] as num?)?.toInt() ?? 12,
    stream: d['stream']?.toString(),
    goals: List<String>.from(d['goals'] ?? const []),
    selectedSubjects: List<String>.from(d['selectedSubjects'] ?? const []),
  );
  Map<String, dynamic> toMap() => {
    'name': name, 'schoolClass': schoolClass, 'stream': stream,
    'goals': goals, 'selectedSubjects': selectedSubjects,
    'profileComplete': true, 'updatedAt': FieldValue.serverTimestamp(),
  };
}

class StudyTask {
  StudyTask(this.subject, this.title, this.minutes, {this.done = false, this.status = 'Pending'});
  String subject, title, status; int minutes; bool done;
}

class StudyMapApp extends StatelessWidget {
  const StudyMapApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false, title: 'StudyMap',
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo, scaffoldBackgroundColor: const Color(0xfff7f8fc)),
    home: const AuthGate(),
  );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override Widget build(BuildContext context) => StreamBuilder<User?>(
    stream: FirebaseAuth.instance.authStateChanges(),
    builder: (context, auth) {
      if (auth.connectionState == ConnectionState.waiting) return const LoadingPage();
      if (!auth.hasData) return const WelcomeScreen();
      final user = auth.data!;
      return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance.collection('users').doc(user.uid).snapshots(),
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) return const LoadingPage();
          final data = snap.data?.data() ?? {};
          if (data['profileComplete'] != true) return ProfileSetup(initialName: (data['name'] ?? user.displayName ?? 'Student').toString());
          return AppShell(profile: StudentProfile.fromMap(data));
        },
      );
    },
  );
}
class LoadingPage extends StatelessWidget { const LoadingPage({super.key}); @override Widget build(BuildContext c) => const Scaffold(body: Center(child: CircularProgressIndicator())); }

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext c) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.map_outlined, size: 90),
              const SizedBox(height: 18),
              const Text(
                'StudyMap',
                style: TextStyle(fontSize: 38, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              const Text(
                'Your smart study planning app',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () => Navigator.push(
                    c,
                    MaterialPageRoute(builder: (_) => const LoginScreen()),
                  ),
                  child: const Text('Login'),
                ),
              ),
              TextButton(
                onPressed: () => Navigator.push(
                  c,
                  MaterialPageRoute(builder: (_) => const SignupScreen()),
                ),
                child: const Text('Create Account'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class LoginScreen extends StatefulWidget { const LoginScreen({super.key}); @override State<LoginScreen> createState() => _LoginScreenState(); }
class _LoginScreenState extends State<LoginScreen> {
  final email = TextEditingController(), password = TextEditingController(); bool loading = false;
  Future<void> login() async { if (email.text.trim().isEmpty || password.text.isEmpty) return; setState(() => loading = true); try { await FirebaseAuth.instance.signInWithEmailAndPassword(email: email.text.trim(), password: password.text); if (mounted) Navigator.popUntil(context, (r) => r.isFirst); } on FirebaseAuthException catch (e) { _msg(e.message ?? 'Login failed'); } finally { if (mounted) setState(() => loading = false); } }
  void _msg(String s) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s))); }
  @override void dispose() { email.dispose(); password.dispose(); super.dispose(); }
  @override Widget build(BuildContext c) => Scaffold(appBar: AppBar(), body: ListView(padding: const EdgeInsets.all(24), children: [const Text('Login', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)), const SizedBox(height: 24), TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder())), const SizedBox(height: 14), TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Password', border: OutlineInputBorder())), const SizedBox(height: 20), FilledButton(onPressed: loading ? null : login, child: Text(loading ? 'Please wait...' : 'Login'))]));
}

class SignupScreen extends StatefulWidget { const SignupScreen({super.key}); @override State<SignupScreen> createState() => _SignupScreenState(); }
class _SignupScreenState extends State<SignupScreen> {
  final name = TextEditingController(), email = TextEditingController(), password = TextEditingController(); bool loading = false;
  Future<void> signup() async { if (name.text.trim().isEmpty || email.text.trim().isEmpty || password.text.length < 6) { _msg('Fill all fields. Password must be at least 6 characters.'); return; } setState(() => loading = true); try { final r = await FirebaseAuth.instance.createUserWithEmailAndPassword(email: email.text.trim(), password: password.text); await FirebaseFirestore.instance.collection('users').doc(r.user!.uid).set({'name': name.text.trim(), 'email': email.text.trim(), 'createdAt': FieldValue.serverTimestamp()}, SetOptions(merge: true)); if (mounted) Navigator.popUntil(context, (r) => r.isFirst); } on FirebaseAuthException catch (e) { _msg(e.message ?? 'Signup failed'); } finally { if (mounted) setState(() => loading = false); } }
  void _msg(String s) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s))); }
  @override void dispose() { name.dispose(); email.dispose(); password.dispose(); super.dispose(); }
  @override Widget build(BuildContext c) => Scaffold(appBar: AppBar(), body: ListView(padding: const EdgeInsets.all(24), children: [const Text('Create Account', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)), const SizedBox(height: 24), TextField(controller: name, decoration: const InputDecoration(labelText: 'Full Name', border: OutlineInputBorder())), const SizedBox(height: 14), TextField(controller: email, decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder())), const SizedBox(height: 14), TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Password (minimum 6 characters)', border: OutlineInputBorder())), const SizedBox(height: 20), FilledButton(onPressed: loading ? null : signup, child: Text(loading ? 'Please wait...' : 'Create Account'))]));
}

class ProfileSetup extends StatefulWidget { const ProfileSetup({super.key, required this.initialName}); final String initialName; @override State<ProfileSetup> createState() => _ProfileSetupState(); }
class _ProfileSetupState extends State<ProfileSetup> {
  int step = 0, selectedClass = 12; String? stream; final goals = <String>{}; late TextEditingController name; bool saving = false;
  final goalOptions = const ['Boards', 'JEE', 'NEET', 'CUET', 'CLAT', 'School Exams', 'UPSC', 'SSC', 'Railway', 'Banking'];
  @override void initState() { super.initState(); name = TextEditingController(text: widget.initialName); }
  @override void dispose() { name.dispose(); super.dispose(); }
  Future<void> next() async { if (step == 0 && name.text.trim().isEmpty) return; if (step == 2 && selectedClass >= 11 && stream == null) return; if (step == 3 && goals.isEmpty) return; if (step < 3) { setState(() => step++); return; } setState(() => saving = true); final p = StudentProfile(name: name.text.trim(), schoolClass: selectedClass, stream: selectedClass >= 11 ? stream : null, goals: goals.toList(), selectedSubjects: subjectsFor(selectedClass, stream)); await FirebaseFirestore.instance.collection('users').doc(FirebaseAuth.instance.currentUser!.uid).set(p.toMap(), SetOptions(merge: true)); if (mounted) setState(() => saving = false); }
  @override
  Widget build(BuildContext c) {
    final titles = [
      'Welcome to StudyMap',
      'Choose Your Class',
      'Choose Your Stream',
      'Your Study Goals',
    ];

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              LinearProgressIndicator(value: (step + 1) / 4),
              const SizedBox(height: 28),
              Text(
                titles[step],
                style: const TextStyle(
                  fontSize: 29,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                'StudyMap will personalize your roadmap based on your choices.',
              ),
              const SizedBox(height: 20),
              Expanded(child: _content()),
              Row(
                children: [
                  if (step > 0)
                    TextButton(
                      onPressed: saving
                          ? null
                          : () => setState(() => step--),
                      child: const Text('Back'),
                    ),
                  const Spacer(),
                  FilledButton(
                    onPressed: saving ? null : next,
                    child: Text(
                      saving
                          ? 'Saving...'
                          : step == 3
                              ? 'Start My Journey'
                              : 'Continue',
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
  Widget _content() { if (step == 0) return TextField(controller: name, decoration: const InputDecoration(labelText: 'Your Name', border: OutlineInputBorder())); if (step == 1) return GridView.count(crossAxisCount: 3, crossAxisSpacing: 8, mainAxisSpacing: 8, children: List.generate(12, (i) { final n = i + 1; return Card(color: selectedClass == n ? Theme.of(context).colorScheme.primaryContainer : null, child: InkWell(onTap: () => setState(() => selectedClass = n), child: Center(child: Text('Class $n')))); })); if (step == 2) { if (selectedClass < 11) return const Center(child: Text('Stream is needed only for Class 11 and 12. Tap Continue.')); return ListView(children: ['Science', 'Commerce', 'Humanities'].map((s) => Card(child: RadioListTile(value: s, groupValue: stream, title: Text(s), onChanged: (v) => setState(() => stream = v)))).toList()); } return ListView(children: goalOptions.map((g) => CheckboxListTile(value: goals.contains(g), title: Text(g), onChanged: (v) => setState(() => v == true ? goals.add(g) : goals.remove(g)))).toList()); }
}

List<String> subjectsFor(int schoolClass, String? stream) {
  if (schoolClass <= 10) return ['Hindi', 'English', 'Mathematics', 'Science', 'Social Science'];
  if (stream == 'Humanities') return ['Hindi', 'English', 'History', 'Political Science', 'Economics', 'Geography'];
  if (stream == 'Science') return ['Hindi', 'English', 'Physics', 'Chemistry', 'Mathematics', 'Biology'];
  if (stream == 'Commerce') return ['Hindi', 'English', 'Accountancy', 'Business Studies', 'Economics', 'Mathematics', 'Applied Mathematics'];
  return ['Hindi', 'English'];
}

class AppShell extends StatefulWidget { const AppShell({super.key, required this.profile}); final StudentProfile profile; @override State<AppShell> createState() => _AppShellState(); }
class _AppShellState extends State<AppShell> {
  int index = 0; late StudentProfile profile; int streak = 1;
  final tasks = <StudyTask>[StudyTask('Welcome', 'Create your first study plan', 20), StudyTask('Focus', 'Complete one important topic', 45)];
  @override void initState() { super.initState(); profile = widget.profile; if (profile.selectedSubjects.isEmpty) profile.selectedSubjects = subjectsFor(profile.schoolClass, profile.stream); }
  Future<void> saveProfile(StudentProfile p) async { await FirebaseFirestore.instance.collection('users').doc(FirebaseAuth.instance.currentUser!.uid).set(p.toMap(), SetOptions(merge: true)); if (mounted) setState(() => profile = p); }
  void refresh() => setState(() {});
  @override Widget build(BuildContext c) { final pages = [HomePage(profile: profile, tasks: tasks, streak: streak, refresh: refresh, open: (i) => setState(() => index = i)), PlannerPage(tasks: tasks, refresh: refresh), RescuePage(profile: profile), ProgressPage(tasks: tasks, streak: streak), ProfilePage(profile: profile, onSave: saveProfile)]; return Scaffold(appBar: AppBar(title: const Text('StudyMap')), body: SafeArea(child: pages[index]), bottomNavigationBar: NavigationBar(selectedIndex: index, onDestinationSelected: (v) => setState(() => index = v), destinations: const [NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'), NavigationDestination(icon: Icon(Icons.map_outlined), selectedIcon: Icon(Icons.map), label: 'Roadmap'), NavigationDestination(icon: Icon(Icons.health_and_safety_outlined), selectedIcon: Icon(Icons.health_and_safety), label: 'Rescue'), NavigationDestination(icon: Icon(Icons.bar_chart_outlined), selectedIcon: Icon(Icons.bar_chart), label: 'Progress'), NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile')])); }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key, required this.profile, required this.tasks, required this.streak, required this.refresh, required this.open});
  final StudentProfile profile; final List<StudyTask> tasks; final int streak; final VoidCallback refresh; final ValueChanged<int> open;
  @override Widget build(BuildContext c) { final done = tasks.where((t) => t.done).length; final progress = tasks.isEmpty ? 0.0 : done / tasks.length; return ListView(padding: const EdgeInsets.all(20), children: [Text('Hello, ${profile.name}', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold)), Text('Class ${profile.schoolClass}${profile.stream == null ? '' : ' • ${profile.stream}'}'), const SizedBox(height: 16), Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text("Today's Progress", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)), const SizedBox(height: 10), LinearProgressIndicator(value: progress), const SizedBox(height: 8), Text('$done of ${tasks.length} tasks completed')]))), Card(child: ListTile(leading: const Icon(Icons.local_fire_department), title: Text('$streak Day Study Streak'), subtitle: Text(streak >= 10 ? 'Congratulations! Amazing consistency!' : 'Keep going to build your streak.'))), _tile(c, Icons.menu_book_outlined, 'Auto Syllabus', 'Subjects, chapters and progress', () => Navigator.push(c, MaterialPageRoute(builder: (_) => SyllabusPage(profile: profile)))), _tile(c, Icons.map_outlined, 'Smart Roadmap', 'Add and manage study tasks', () => open(1)), _tile(c, Icons.calendar_month_outlined, 'Smart Timetable', 'Suggested daily study routine', () => Navigator.push(c, MaterialPageRoute(builder: (_) => TimetablePage(tasks: tasks)))), _tile(c, Icons.lock_outline, 'Focus Lock', 'Block distracting apps during study', () => Navigator.push(c, MaterialPageRoute(builder: (_) => const FocusLockPage()))), _tile(c, Icons.workspace_premium_outlined, 'StudyMap Premium', 'AI Assistant and premium tools', () => Navigator.push(c, MaterialPageRoute(builder: (_) => const PremiumPage()))), const SizedBox(height: 10), const FocusTimer()]); }
  Widget _tile(BuildContext c, IconData i, String t, String s, VoidCallback f) => Card(child: ListTile(leading: Icon(i), title: Text(t), subtitle: Text(s), trailing: const Icon(Icons.chevron_right), onTap: f));
}

class SyllabusPage extends StatelessWidget {
  const SyllabusPage({super.key, required this.profile});

  final StudentProfile profile;

  @override
  Widget build(BuildContext c) {
    final subjects = profile.selectedSubjects.isEmpty
        ? subjectsFor(profile.schoolClass, profile.stream)
        : profile.selectedSubjects;

    return Scaffold(
      appBar: AppBar(title: const Text('Auto Syllabus')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            'Class ${profile.schoolClass}${profile.stream == null ? '' : ' • ${profile.stream}'}',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          ...subjects.map(
            (s) => Card(
              child: ListTile(
                leading: const Icon(Icons.menu_book),
                title: Text(s),
                subtitle: const Text('Tap to open chapters and topics'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.push(
                  c,
                  MaterialPageRoute(
                    builder: (_) => SubjectPage(
                      subject: s,
                      schoolClass: profile.schoolClass,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class SubjectPage extends StatefulWidget { const SubjectPage({super.key, required this.subject, required this.schoolClass}); final String subject; final int schoolClass; @override State<SubjectPage> createState() => _SubjectPageState(); }
class _SubjectPageState extends State<SubjectPage> {
  late final List<_Topic> topics;

  @override
  void initState() {
    super.initState();
    topics = chapterTopics(widget.subject, widget.schoolClass)
        .map((e) => _Topic(e))
        .toList();
  }

  @override
  Widget build(BuildContext c) {
    final completed = topics.where((t) => t.status == 'Completed').length;

    return Scaffold(
      appBar: AppBar(title: Text(widget.subject)),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            '$completed / ${topics.length} completed',
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          ...topics.map(
            (t) => Card(
              child: ListTile(
                title: Text(t.name),
                subtitle: Text(t.status),
                trailing: DropdownButton<String>(
                  value: t.status,
                  items: const ['Pending', 'Completed', 'Revision']
                      .map(
                        (x) => DropdownMenuItem(value: x, child: Text(x)),
                      )
                      .toList(),
                  onChanged: (v) {
                    if (v != null) setState(() => t.status = v);
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Topic { _Topic(this.name, [this.status = 'Pending']); final String name; String status; }
List<String> chapterTopics(String subject, int schoolClass) { final base = <String, List<String>>{'Hindi':['गद्य खंड','काव्य खंड','व्याकरण','लेखन'], 'English':['Reading Skills','Writing Skills','Grammar','Literature'], 'Mathematics':['Algebra','Geometry','Calculus','Statistics'], 'Science':['Physics','Chemistry','Biology'], 'Social Science':['History','Geography','Civics','Economics'], 'History':['Ancient Themes','Medieval Themes','Modern India'], 'Political Science':['Constitution','Political Theory','Indian Politics'], 'Economics':['Micro Economics','Macro Economics','Development'], 'Geography':['Human Geography','India: People and Economy','Maps and Practice'], 'Physics':['Mechanics','Electricity','Magnetism','Modern Physics'], 'Chemistry':['Physical Chemistry','Organic Chemistry','Inorganic Chemistry'], 'Biology':['Cell Biology','Human Physiology','Genetics','Ecology'], 'Accountancy':['Journal Entries','Ledger','Final Accounts'], 'Business Studies':['Management','Marketing','Finance'], 'Mathematics / Biology':['Core Topics','Practice'], 'Applied Mathematics':['Financial Mathematics','Statistics']}; return base[subject] ?? ['Chapter 1','Chapter 2','Chapter 3']; }

class PlannerPage extends StatefulWidget { const PlannerPage({super.key, required this.tasks, required this.refresh}); final List<StudyTask> tasks; final VoidCallback refresh; @override State<PlannerPage> createState() => _PlannerPageState(); }
class _PlannerPageState extends State<PlannerPage> {
  void addTask() { final subject = TextEditingController(), title = TextEditingController(), mins = TextEditingController(text: '30'); showModalBottomSheet(context: context, isScrollControlled: true, builder: (c) => Padding(padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(c).viewInsets.bottom + 20), child: Column(mainAxisSize: MainAxisSize.min, children: [const Text('Add Study Task', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), TextField(controller: subject, decoration: const InputDecoration(labelText: 'Subject')), TextField(controller: title, decoration: const InputDecoration(labelText: 'Topic / Task')), TextField(controller: mins, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Minutes')), const SizedBox(height: 12), FilledButton(onPressed: () { if (subject.text.trim().isEmpty || title.text.trim().isEmpty) return; setState(() => widget.tasks.add(StudyTask(subject.text.trim(), title.text.trim(), int.tryParse(mins.text) ?? 30))); widget.refresh(); Navigator.pop(c); }, child: const Text('Save Task'))]))); }
  @override Widget build(BuildContext c) => ListView(padding: const EdgeInsets.all(20), children: [const Text('Smart Roadmap', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)), const SizedBox(height: 8), const Text('Build your personal daily study plan.'), const SizedBox(height: 16), ...widget.tasks.map((t) => Card(child: CheckboxListTile(value: t.done, title: Text(t.title), subtitle: Text('${t.subject} • ${t.minutes} min • ${t.status}'), onChanged: (v) { setState(() { t.done = v ?? false; t.status = t.done ? 'Completed' : 'Pending'; }); widget.refresh(); }))), FilledButton.icon(onPressed: addTask, icon: const Icon(Icons.add), label: const Text('Add Study Task'))]);
}

class TimetablePage extends StatelessWidget { const TimetablePage({super.key, required this.tasks}); final List<StudyTask> tasks; @override Widget build(BuildContext c) => Scaffold(appBar: AppBar(title: const Text('Smart Timetable')), body: ListView(padding: const EdgeInsets.all(20), children: [const Text('Suggested routine', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), const SizedBox(height: 12), _slot('Morning', '45 min • Difficult topic'), _slot('Afternoon', '30 min • Practice / homework'), _slot('Evening', '45 min • Current roadmap task'), const SizedBox(height: 12), const Text('Your tasks', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), ...tasks.map((t) => Card(child: ListTile(title: Text(t.title), subtitle: Text('${t.subject} • ${t.minutes} min'))))])); Widget _slot(String a, String b) => Card(child: ListTile(leading: const Icon(Icons.schedule), title: Text(a), subtitle: Text(b))); }

class RescuePage extends StatefulWidget { const RescuePage({super.key, required this.profile}); final StudentProfile profile; @override State<RescuePage> createState() => _RescuePageState(); }
class _RescuePageState extends State<RescuePage> {
  double missed = 3;
  double hours = 4;

  @override
  Widget build(BuildContext c) {
    final intensity = widget.profile.goals.isEmpty
        ? 1
        : widget.profile.goals.length.clamp(1, 3);
    final taskCount = ((missed * 2 * intensity) / hours).ceil().clamp(1, 12);

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text(
          'Study Rescue',
          style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
        ),
        const Text("Don't Restart. Recover."),
        const SizedBox(height: 20),
        Text('Missed study days: ${missed.round()}'),
        Slider(
          value: missed,
          min: 1,
          max: 60,
          divisions: 59,
          label: missed.round().toString(),
          onChanged: (v) => setState(() => missed = v),
        ),
        Text('Available hours/day: ${hours.round()}'),
        Slider(
          value: hours,
          min: 1,
          max: 12,
          divisions: 11,
          onChanged: (v) => setState(() => hours = v),
        ),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Recovery Plan',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                Text(
                  'Based on Class ${widget.profile.schoolClass}'
                  '${widget.profile.stream == null ? '' : ' • ${widget.profile.stream}'}',
                ),
                Text('Day 1: $taskCount priority tasks'),
                Text('Day 2: $taskCount priority tasks + revision'),
                const Text('Day 3: Light revision + practice'),
                const SizedBox(height: 8),
                const Text('Small steps. Back on track.'),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class ProgressPage extends StatelessWidget { const ProgressPage({super.key, required this.tasks, required this.streak}); final List<StudyTask> tasks; final int streak; @override Widget build(BuildContext c) { final done = tasks.where((e) => e.done).length; final minutes = tasks.where((e) => e.done).fold<int>(0, (s, t) => s + t.minutes); final rate = tasks.isEmpty ? 0 : ((done / tasks.length) * 100).round(); return ListView(padding: const EdgeInsets.all(20), children: [const Text('Progress', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)), const SizedBox(height: 18), _card('Completed Tasks', '$done / ${tasks.length}'), _card('Study Time', '$minutes min'), _card('Completion Rate', '$rate%'), _card('Current Streak', '$streak days'), if (streak >= 10) const Card(child: ListTile(leading: Icon(Icons.celebration), title: Text('Congratulations! 10 day streak complete!'))) ]); } Widget _card(String a, String b) => Card(child: ListTile(title: Text(a), trailing: Text(b, style: const TextStyle(fontWeight: FontWeight.bold)))); }

class ProfilePage extends StatefulWidget { const ProfilePage({super.key, required this.profile, required this.onSave}); final StudentProfile profile; final ValueChanged<StudentProfile> onSave; @override State<ProfilePage> createState() => _ProfilePageState(); }
class _ProfilePageState extends State<ProfilePage> { late TextEditingController name; late int schoolClass; String? stream; late Set<String> subjects;
  @override void initState() { super.initState(); name = TextEditingController(text: widget.profile.name); schoolClass = widget.profile.schoolClass; stream = widget.profile.stream; subjects = (widget.profile.selectedSubjects.isEmpty ? subjectsFor(schoolClass, stream) : widget.profile.selectedSubjects).toSet(); }
  @override void dispose() { name.dispose(); super.dispose(); }
  void save() { final p = StudentProfile(name: name.text.trim().isEmpty ? 'Student' : name.text.trim(), schoolClass: schoolClass, stream: schoolClass >= 11 ? stream : null, goals: widget.profile.goals, selectedSubjects: subjects.toList()); widget.onSave(p); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Profile updated successfully'))); }
  @override Widget build(BuildContext c) { final available = subjectsFor(schoolClass, stream); return ListView(padding: const EdgeInsets.all(20), children: [const Center(child: CircleAvatar(radius: 42, child: Icon(Icons.person, size: 44))), const SizedBox(height: 12), const Center(child: Text('Student Profile', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold))), const SizedBox(height: 24), TextField(controller: name, decoration: const InputDecoration(labelText: 'Name', border: OutlineInputBorder())), const SizedBox(height: 14), DropdownButtonFormField<int>(value: schoolClass, decoration: const InputDecoration(labelText: 'Class', border: OutlineInputBorder()), items: List.generate(12, (i) => DropdownMenuItem(value: i + 1, child: Text('Class ${i + 1}'))), onChanged: (v) => setState(() { schoolClass = v!; if (schoolClass < 11) stream = null; subjects = subjectsFor(schoolClass, stream).toSet(); })), const SizedBox(height: 14), if (schoolClass >= 11) DropdownButtonFormField<String>(value: stream, decoration: const InputDecoration(labelText: 'Stream', border: OutlineInputBorder()), items: const ['Science', 'Commerce', 'Humanities'].map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(), onChanged: (v) => setState(() { stream = v; subjects = subjectsFor(schoolClass, stream).toSet(); })), const SizedBox(height: 16), const Text('Subjects', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), ...available.map((s) => CheckboxListTile(value: subjects.contains(s), title: Text(s), onChanged: (v) => setState(() => v == true ? subjects.add(s) : subjects.remove(s)))), const SizedBox(height: 12), FilledButton(onPressed: save, child: const Text('Save Profile')), const SizedBox(height: 8), OutlinedButton.icon(onPressed: () => FirebaseAuth.instance.signOut(), icon: const Icon(Icons.logout), label: const Text('Logout'))]); }
}

class FocusLockPage extends StatefulWidget {
  const FocusLockPage({super.key});
  @override State<FocusLockPage> createState() => _FocusLockPageState();
}

class _FocusLockPageState extends State<FocusLockPage> {
  final Map<String, String> apps = const {
    'Instagram': 'com.instagram.android',
    'YouTube': 'com.google.android.youtube',
    'Facebook': 'com.facebook.katana',
    'WhatsApp': 'com.whatsapp',
    'Chrome': 'com.android.chrome',
    'Free Fire': 'com.dts.freefireth',
    'Free Fire MAX': 'com.dts.freefiremax',
    'BGMI': 'com.pubg.imobile',
  };
  final Set<String> selected = <String>{};
  int minutes = 30;
  bool enabled = false;

  Future<void> start() async {
    if (selected.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Pehle distracting apps select karo.')));
      return;
    }
    final ok = await FocusLockNative.isAccessibilityEnabled();
    if (!ok) {
      await FocusLockNative.openAccessibilitySettings();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Accessibility me StudyMap ko ON karo, phir wapas aakar Start dabao.')));
      return;
    }
    await FocusLockNative.startLock(packages: selected.toList(), minutes: minutes);
    if (mounted) setState(() => enabled = true);
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Focus Lock ${minutes} minutes ke liye ON hai.')));
  }

  Future<void> stop() async {
    await FocusLockNative.stopLock();
    if (mounted) setState(() => enabled = false);
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Focus Lock')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Distraction Blocker', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        const Text('Selected apps ko study session ke dauran open karne par StudyMap wapas Focus screen par laayega.'),
        const SizedBox(height: 12),
        const Text('Lock duration'),
        DropdownButton<int>(value: minutes, items: const [15,30,45,60,90,120].map((m) => DropdownMenuItem(value:m, child:Text('$m minutes'))).toList(), onChanged: enabled ? null : (v) { if(v!=null) setState(()=>minutes=v); }),
      ])),
      const SizedBox(height: 10),
      ...apps.entries.map((e) => CheckboxListTile(value: selected.contains(e.value), onChanged: enabled ? null : (v) => setState(() { if(v==true) selected.add(e.value); else selected.remove(e.value); }), title: Text(e.key), subtitle: Text(e.value))),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: enabled ? stop : start, icon: Icon(enabled ? Icons.stop : Icons.lock), label: Text(enabled ? 'Stop Focus Lock' : 'Start Focus Lock')),
      const SizedBox(height: 8),
      const Text('Note: Android Accessibility permission ON rehna zaroori hai. Ye feature sirf tumhare selected apps ko session ke dauran restrict karta hai.'),
    ]),
  );
}

class FocusTimer extends StatefulWidget { const FocusTimer({super.key}); @override State<FocusTimer> createState() => _FocusTimerState(); }
class _FocusTimerState extends State<FocusTimer> { int selectedMinutes = 25, seconds = 25 * 60; Timer? timer; bool running = false; void toggle() { if (running) { timer?.cancel(); setState(() => running = false); } else { setState(() => running = true); timer = Timer.periodic(const Duration(seconds: 1), (_) { if (seconds <= 1) { timer?.cancel(); setState(() { running = false; seconds = selectedMinutes * 60; }); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Focus session completed! Great job!'))); } else { setState(() => seconds--); } }); } } void setDuration(int m) { timer?.cancel(); setState(() { selectedMinutes = m; seconds = m * 60; running = false; }); } @override void dispose() { timer?.cancel(); super.dispose(); } @override Widget build(BuildContext c) { final m = (seconds ~/ 60).toString().padLeft(2, '0'); final s = (seconds % 60).toString().padLeft(2, '0'); return Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [const Text('Focus Timer', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), const SizedBox(height: 8), DropdownButton<int>(value: selectedMinutes, items: const [15, 25, 30, 45, 60, 90].map((x) => DropdownMenuItem(value: x, child: Text('$x minutes'))).toList(), onChanged: running ? null : (v) { if (v != null) setDuration(v); }), Text('$m:$s', style: const TextStyle(fontSize: 40, fontWeight: FontWeight.bold)), FilledButton(onPressed: toggle, child: Text(running ? 'Pause' : 'Start Focus')), TextButton(onPressed: () => setDuration(selectedMinutes), child: const Text('Reset'))]))); }
}

class PremiumPage extends StatelessWidget { const PremiumPage({super.key}); @override Widget build(BuildContext c) => Scaffold(appBar: AppBar(title: const Text('StudyMap Premium')), body: ListView(padding: const EdgeInsets.all(20), children: [const Text('Premium • ₹49 / month', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)), const SizedBox(height: 10), const Text('Premium AI features can be connected after a secure AI backend and payment system are added.'), const SizedBox(height: 18), ...const [('AI Study Assistant','Ask study questions and get explanations'),('AI Smart Planner','Personalized study planning'),('Advanced Analytics','Weak topics and performance insights'),('AI Notes Helper','Summaries and revision notes'),('AI Mock Test','Practice questions'),('Cloud Backup & Sync','Keep your study data safe')].map((x) => Card(child: ListTile(leading: const Icon(Icons.workspace_premium), title: Text(x.$1), subtitle: Text(x.$2)))), const SizedBox(height: 12), FilledButton(onPressed: () => ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content: Text('Premium payment and AI backend will be added in the next phase.'))), child: const Text('Upgrade Coming Soon'))])); }
