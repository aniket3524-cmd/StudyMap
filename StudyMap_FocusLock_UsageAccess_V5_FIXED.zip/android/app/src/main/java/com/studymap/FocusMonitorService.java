package com.studymap;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Collections;
import java.util.Set;

public class FocusMonitorService extends Service {

    private static final String PREFS = "studymap_focus_lock_v5";
    private static final String CHANNEL_ID = "studymap_focus";
    private static final int NOTIFICATION_ID = 731;

    private Handler handler;
    private ViewLockOverlay overlay;
    private UsageStatsManager usageStatsManager;
    private WindowManager windowManager;

    private final Runnable checker = new Runnable() {
        @Override
        public void run() {
            checkForegroundApp();
            if (handler != null) {
                handler.postDelayed(this, 600);
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();

        handler = new Handler();
        usageStatsManager =
                (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
        windowManager =
                (WindowManager) getSystemService(Context.WINDOW_SERVICE);

        createChannel();
        startForeground(NOTIFICATION_ID, notification());
        handler.post(checker);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    private void checkForegroundApp() {
        long until = getSharedPreferences(PREFS, 0)
                .getLong("until", 0);

        if (until <= System.currentTimeMillis()) {
            removeOverlay();
            stopSelf();
            return;
        }

        Set<String> blocked = getSharedPreferences(PREFS, 0)
                .getStringSet("packages", Collections.emptySet());

        if (blocked.isEmpty()) {
            removeOverlay();
            return;
        }

        String foreground = getForegroundPackage();

        if (foreground != null && blocked.contains(foreground)) {
            showOverlay();
        } else {
            // The user left the blocked application.
            // Remove the overlay immediately so Home and other apps work.
            removeOverlay();
        }
    }

    private String getForegroundPackage() {
        if (usageStatsManager == null) {
            return null;
        }

        long end = System.currentTimeMillis();
        long start = end - 1800;

        UsageEvents events =
                usageStatsManager.queryEvents(start, end);

        UsageEvents.Event event = new UsageEvents.Event();
        String latestPackage = null;
        long latestTime = 0;

        while (events.hasNextEvent()) {
            events.getNextEvent(event);

            int type = event.getEventType();
            if (type == UsageEvents.Event.ACTIVITY_RESUMED
                    || type == UsageEvents.Event.MOVE_TO_FOREGROUND) {

                if (event.getTimeStamp() >= latestTime) {
                    latestTime = event.getTimeStamp();
                    latestPackage = event.getPackageName();
                }
            }
        }

        return latestPackage;
    }

    private void showOverlay() {
        if (overlay != null || !Settings.canDrawOverlays(this)) {
            return;
        }

        overlay = new ViewLockOverlay(this);

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        // Do NOT use FLAG_NOT_FOCUSABLE: that would let touches pass through
        // to the blocked app. The overlay must receive touches itself.
        int flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;

        WindowManager.LayoutParams params =
                new WindowManager.LayoutParams(
                        WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.MATCH_PARENT,
                        type,
                        flags,
                        PixelFormat.TRANSLUCENT
                );

        params.gravity = Gravity.CENTER;

        try {
            windowManager.addView(overlay, params);
        } catch (Exception e) {
            overlay = null;
        }
    }

    private void removeOverlay() {
        if (overlay == null) {
            return;
        }

        try {
            if (windowManager != null) {
                windowManager.removeView(overlay);
            }
        } catch (Exception ignored) {
        }

        overlay = null;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "StudyMap Focus Lock",
                    NotificationManager.IMPORTANCE_LOW
            );

            NotificationManager manager =
                    getSystemService(NotificationManager.class);

            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private Notification notification() {
        Intent intent = new Intent(this, MainActivity.class);

        PendingIntent pendingIntent = PendingIntent.getActivity(
                this,
                0,
                intent,
                PendingIntent.FLAG_IMMUTABLE
                        | PendingIntent.FLAG_UPDATE_CURRENT
        );

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            return new Notification.Builder(this, CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
                    .setContentTitle("StudyMap Focus Lock")
                    .setContentText("Focus Lock is active")
                    .setContentIntent(pendingIntent)
                    .setOngoing(true)
                    .build();
        }

        return new Notification.Builder(this)
                .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
                .setContentTitle("StudyMap Focus Lock")
                .setContentText("Focus Lock is active")
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build();
    }

    @Override
    public void onDestroy() {
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }

        removeOverlay();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private static class ViewLockOverlay extends LinearLayout {

        ViewLockOverlay(Context context) {
            super(context);

            setOrientation(VERTICAL);
            setGravity(Gravity.CENTER);
            setPadding(48, 48, 48, 48);
            setBackgroundColor(Color.WHITE);

            TextView title = new TextView(context);
            title.setText("StudyMap Focus Lock");
            title.setTextSize(28);
            title.setTextColor(Color.BLACK);
            title.setGravity(Gravity.CENTER);

            TextView message = new TextView(context);
            message.setText(
                    "This selected app is locked during your study session.\n\n"
                            + "You can return to StudyMap or leave this screen."
            );
            message.setTextSize(17);
            message.setTextColor(Color.DKGRAY);
            message.setGravity(Gravity.CENTER);
            message.setPadding(0, 24, 0, 24);

            Button studyMapButton = new Button(context);
            studyMapButton.setText("Open StudyMap");
            studyMapButton.setOnClickListener(v -> {
                try {
                    Intent intent = new Intent(context, MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                            | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    context.startActivity(intent);
                } catch (Exception ignored) {
                }
            });

            addView(title, new LinearLayout.LayoutParams(
                    LayoutParams.MATCH_PARENT,
                    LayoutParams.WRAP_CONTENT
            ));

            addView(message, new LinearLayout.LayoutParams(
                    LayoutParams.MATCH_PARENT,
                    LayoutParams.WRAP_CONTENT
            ));

            addView(studyMapButton, new LinearLayout.LayoutParams(
                    LayoutParams.WRAP_CONTENT,
                    LayoutParams.WRAP_CONTENT
            ));
        }
    }
}
