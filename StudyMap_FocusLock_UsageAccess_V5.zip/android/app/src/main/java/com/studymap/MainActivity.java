package com.studymap;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.app.AppOpsManager;
import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;

public class MainActivity extends FlutterActivity {
  private static final String CHANNEL = "studymap/focus_lock_v5";
  private static final String PREFS = "studymap_focus_lock_v5";

  @Override public void configureFlutterEngine(FlutterEngine flutterEngine) {
    super.configureFlutterEngine(flutterEngine);
    new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), CHANNEL)
      .setMethodCallHandler((call, result) -> {
        switch (call.method) {
          case "hasUsageAccess": result.success(hasUsageAccess(this)); break;
          case "openUsageAccessSettings":
            startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)); result.success(null); break;
          case "hasOverlayPermission": result.success(Settings.canDrawOverlays(this)); break;
          case "openOverlaySettings":
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
              Uri.parse("package:" + getPackageName()))); result.success(null); break;
          case "startLock": {
            java.util.List<String> pkgs = call.argument("packages");
            Integer mins = call.argument("minutes");
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
              .putStringSet("packages", new java.util.HashSet<>(pkgs == null ? java.util.Collections.emptyList() : pkgs))
              .putLong("until", System.currentTimeMillis() + (mins == null ? 60 : mins) * 60_000L).apply();
            Intent i = new Intent(this, FocusMonitorService.class);
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            result.success(null); break;
          }
          case "stopLock":
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putLong("until", 0).apply();
            stopService(new Intent(this, FocusMonitorService.class)); result.success(null); break;
          default: result.notImplemented();
        }
      });
  }

  static boolean hasUsageAccess(Context c) {
    AppOpsManager appOps = (AppOpsManager)c.getSystemService(Context.APP_OPS_SERVICE);
    int mode = appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
      android.os.Process.myUid(), c.getPackageName());
    return mode == AppOpsManager.MODE_ALLOWED;
  }
}
