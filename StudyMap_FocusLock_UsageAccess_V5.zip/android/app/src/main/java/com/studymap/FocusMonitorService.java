package com.studymap;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import java.util.*;

public class FocusMonitorService extends Service {
  private static final String PREFS="studymap_focus_lock_v5";
  private static final int NOTIF=731;
  private Handler handler; private String lastBlocked=""; private View overlay;
  private final Runnable checker = new Runnable(){ public void run(){ check(); if(handler!=null) handler.postDelayed(this,800); }};

  @Override public void onCreate(){ super.onCreate(); handler=new Handler(Looper.getMainLooper()); createChannel(); startForeground(NOTIF, notification()); handler.post(checker); }
  @Override public int onStartCommand(Intent i,int f,int s){ return START_STICKY; }
  @Override public void onDestroy(){ if(handler!=null) handler.removeCallbacksAndMessages(null); removeOverlay(); super.onDestroy(); }
  @Override public android.os.IBinder onBind(Intent i){ return null; }

  private void check(){
    long until=getSharedPreferences(PREFS,0).getLong("until",0);
    if(until<=System.currentTimeMillis()){ removeOverlay(); stopSelf(); return; }
    Set<String> blocked=getSharedPreferences(PREFS,0).getStringSet("packages",Collections.emptySet());
    if(blocked.isEmpty()) return;
    UsageStatsManager usm=(UsageStatsManager)getSystemService(USAGE_STATS_SERVICE);
    UsageEvents ev=usm.queryEvents(System.currentTimeMillis()-2500,System.currentTimeMillis());
    UsageEvents.Event e=new UsageEvents.Event(); String foreground=null;
    while(ev.hasNextEvent()){ ev.getNextEvent(e); int t=e.getEventType(); if(t==UsageEvents.Event.ACTIVITY_RESUMED || t==UsageEvents.Event.MOVE_TO_FOREGROUND) foreground=e.getPackageName(); }
    if(foreground!=null && blocked.contains(foreground)){ lastBlocked=foreground; showOverlay(); } else if(!blocked.contains(lastBlocked)) removeOverlay();
  }

  private void showOverlay(){ if(overlay!=null || !Settings.canDrawOverlays(this)) return;
    final WindowManager wm=(WindowManager)getSystemService(WINDOW_SERVICE);
    LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER); box.setPadding(48,48,48,48); box.setBackgroundColor(Color.WHITE);
    TextView title=new TextView(this); title.setText("StudyMap Focus Lock"); title.setTextSize(28); title.setTextColor(Color.BLACK); title.setGravity(Gravity.CENTER);
    TextView sub=new TextView(this); sub.setText("This app is locked during your study session.\nReturn to StudyMap and keep studying."); sub.setTextSize(18); sub.setTextColor(Color.DKGRAY); sub.setGravity(Gravity.CENTER); sub.setPadding(0,24,0,24);
    box.addView(title,new LinearLayout.LayoutParams(-1,-2)); box.addView(sub,new LinearLayout.LayoutParams(-1,-2));
    overlay=box;
    int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
    WindowManager.LayoutParams lp=new WindowManager.LayoutParams(-1,-1,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
    try{wm.addView(overlay,lp);}catch(Exception ex){overlay=null;}
  }
  private void removeOverlay(){ if(overlay!=null){try{((WindowManager)getSystemService(WINDOW_SERVICE)).removeView(overlay);}catch(Exception ignored){} overlay=null;} }

  private void createChannel(){ if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel("studymap_focus","StudyMap Focus Lock",NotificationManager.IMPORTANCE_LOW); getSystemService(NotificationManager.class).createNotificationChannel(c);} }
  private Notification notification(){ Intent i=new Intent(this,MainActivity.class); PendingIntent pi=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT); return new Notification.Builder(this,"studymap_focus").setSmallIcon(android.R.drawable.ic_lock_idle_lock).setContentTitle("StudyMap Focus Lock").setContentText("Focus Lock is active").setContentIntent(pi).setOngoing(true).build(); }
}
