package com.studymap;

import android.app.AppOpsManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;

import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;

public class MainActivity extends FlutterActivity {
    private static final String CHANNEL = "studymap/focus_lock_v5";
    private static final String PREFS = "studymap_focus_lock_v5";

    @Override
    public void configureFlutterEngine(FlutterEngine flutterEngine) {
        super.configureFlutterEngine(flutterEngine);

        new MethodChannel(
                flutterEngine.getDartExecutor().getBinaryMessenger(),
                CHANNEL
        ).setMethodCallHandler((call, result) -> {
            switch (call.method) {
                case "hasUsageAccess":
                    result.success(hasUsageAccess(this));
                    break;

                case "openUsageAccessSettings":
                    startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
                    result.success(null);
                    break;

                case "hasOverlayPermission":
                    result.success(Settings.canDrawOverlays(this));
                    break;

                case "openOverlaySettings":
                    startActivity(new Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName())
                    ));
                    result.success(null);
                    break;

                case "startLock": {
                    List<String> packages = call.argument("packages");
                    Integer minutes = call.argument("minutes");

                    if (packages == null) {
                        packages = Collections.emptyList();
                    }

                    long durationMinutes = minutes == null ? 60L : minutes.longValue();
                    if (durationMinutes < 1) durationMinutes = 1;

                    long until = System.currentTimeMillis()
                            + durationMinutes * 60_000L;

                    getSharedPreferences(PREFS, MODE_PRIVATE)
                            .edit()
                            .putStringSet(
                                    "packages",
                                    new HashSet<>(packages)
                            )
                            .putLong("until", until)
                            .apply();

                    Intent serviceIntent = new Intent(
                            this,
                            FocusMonitorService.class
                    );
                    serviceIntent.putStringArrayListExtra(
                            "packages",
                            new java.util.ArrayList<>(packages)
                    );
                    serviceIntent.putExtra("until", until);

                    if (android.os.Build.VERSION.SDK_INT >= 26) {
                        startForegroundService(serviceIntent);
                    } else {
                        startService(serviceIntent);
                    }

                    result.success(null);
                    break;
                }

                case "stopLock":
                    getSharedPreferences(PREFS, MODE_PRIVATE)
                            .edit()
                            .clear()
                            .apply();

                    stopService(new Intent(
                            this,
                            FocusMonitorService.class
                    ));

                    result.success(null);
                    break;

                default:
                    result.notImplemented();
            }
        });
    }

    static boolean hasUsageAccess(Context context) {
        AppOpsManager appOps =
                (AppOpsManager) context.getSystemService(
                        Context.APP_OPS_SERVICE
                );

        if (appOps == null) return false;

        int mode = appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(),
                context.getPackageName()
        );

        return mode == AppOpsManager.MODE_ALLOWED;
    }
}
