# StudyMap V4 – Auto Syllabus System

## New Features
- Board selection: CBSE, Bihar Board, ICSE
- Class 1–12 selection
- Stream selection for Class 11–12
- Goals: Boards, JEE, NEET, CUET, CLAT
- Automatic subject suggestions
- Subject review and selection
- Starter syllabus/topic library

## Important
The syllabus entries in this prototype are starter/sample structures for app development.
Before publishing StudyMap, official current syllabi should be researched, verified, versioned by academic year, and stored in a remotely updateable database.

## Next
V5: Smart timetable generator, study sessions, reminders and daily schedule.
