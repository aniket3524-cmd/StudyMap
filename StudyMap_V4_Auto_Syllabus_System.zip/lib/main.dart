import 'package:flutter/material.dart';

void main() => runApp(const StudyMapApp());

class StudyMapApp extends StatelessWidget {
  const StudyMapApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'StudyMap V4',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
        scaffoldBackgroundColor: const Color(0xFFF7F8FC),
      ),
      home: const V4Home(),
    );
  }
}

class Subject {
  Subject(this.name, this.chapters);
  final String name;
  final List<String> chapters;
}

class EducationProfile {
  String board = 'CBSE';
  int schoolClass = 12;
  String stream = 'Humanities';
  final Set<String> goals = {'Boards'};
  final List<Subject> selectedSubjects = [];
}

class V4Home extends StatefulWidget {
  const V4Home({super.key});
  @override
  State<V4Home> createState() => _V4HomeState();
}

class _V4HomeState extends State<V4Home> {
  final profile = EducationProfile();

  @override
  void initState() {
    super.initState();
    _loadSuggestions();
  }

  void _loadSuggestions() {
    profile.selectedSubjects
      ..clear()
      ..addAll(SyllabusLibrary.suggest(profile));
  }

  void _openSetup() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => SetupPage(
          profile: profile,
          onChanged: () => setState(_loadSuggestions),
        ),
      ),
    );
    setState(() {});
  }

  void _openSubjects() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => SubjectSelectionPage(profile: profile),
      ),
    ).then((_) => setState(() {}));
  }

  void _openLibrary() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => SyllabusLibraryPage(subjects: profile.selectedSubjects),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final chapters = profile.selectedSubjects.fold<int>(0, (sum, s) => sum + s.chapters.length);
    return Scaffold(
      appBar: AppBar(title: const Text('StudyMap V4')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('Auto Syllabus System 📚',
              style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          const Text('Select your education profile and get suggested subjects automatically.'),
          const SizedBox(height: 18),
          Card(
            child: ListTile(
              leading: const Icon(Icons.school),
              title: Text('${profile.board} • Class ${profile.schoolClass}'),
              subtitle: Text(
                '${profile.stream} • ${profile.goals.join(', ')}',
              ),
              trailing: const Icon(Icons.edit),
              onTap: _openSetup,
            ),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              _metric('Subjects', '${profile.selectedSubjects.length}'),
              _metric('Sample Chapters', '$chapters'),
            ],
          ),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: _openSubjects,
            icon: const Icon(Icons.auto_awesome),
            label: const Text('Review Suggested Subjects'),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: _openLibrary,
            icon: const Icon(Icons.menu_book),
            label: const Text('Open Syllabus Library'),
          ),
          const SizedBox(height: 20),
          const Text('Suggested for you',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          ...profile.selectedSubjects.map(
            (s) => Card(
              child: ListTile(
                leading: const CircleAvatar(child: Icon(Icons.book)),
                title: Text(s.name),
                subtitle: Text('${s.chapters.length} sample topics'),
              ),
            ),
          ),
          const SizedBox(height: 20),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                'Important: V4 includes a starter syllabus structure for app development. '
                'Before publishing, official board/exam syllabus data should be verified and updated.',
                style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _metric(String label, String value) => SizedBox(
        width: 160,
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              children: [
                Text(value,
                    style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                Text(label),
              ],
            ),
          ),
        ),
      );
}

class SetupPage extends StatefulWidget {
  const SetupPage({super.key, required this.profile, required this.onChanged});
  final EducationProfile profile;
  final VoidCallback onChanged;
  @override
  State<SetupPage> createState() => _SetupPageState();
}

class _SetupPageState extends State<SetupPage> {
  final boards = const ['CBSE', 'Bihar Board', 'ICSE'];
  final streams = const ['Science', 'Commerce', 'Humanities'];
  final goals = const ['Boards', 'JEE', 'NEET', 'CUET', 'CLAT'];

  @override
  Widget build(BuildContext context) {
    final needsStream = widget.profile.schoolClass >= 11;
    return Scaffold(
      appBar: AppBar(title: const Text('Education Setup')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('Board', style: TextStyle(fontWeight: FontWeight.bold)),
          DropdownButtonFormField<String>(
            value: widget.profile.board,
            items: boards.map((b) => DropdownMenuItem(value: b, child: Text(b))).toList(),
            onChanged: (v) => setState(() => widget.profile.board = v!),
          ),
          const SizedBox(height: 20),
          const Text('Class', style: TextStyle(fontWeight: FontWeight.bold)),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: List.generate(
              12,
              (i) => ChoiceChip(
                label: Text('Class ${i + 1}'),
                selected: widget.profile.schoolClass == i + 1,
                onSelected: (_) => setState(() => widget.profile.schoolClass = i + 1),
              ),
            ),
          ),
          if (needsStream) ...[
            const SizedBox(height: 20),
            const Text('Stream', style: TextStyle(fontWeight: FontWeight.bold)),
            ...streams.map(
              (s) => RadioListTile<String>(
                value: s,
                groupValue: widget.profile.stream,
                title: Text(s),
                onChanged: (v) => setState(() => widget.profile.stream = v!),
              ),
            ),
          ],
          const SizedBox(height: 20),
          const Text('Goals', style: TextStyle(fontWeight: FontWeight.bold)),
          ...goals.map(
            (g) => CheckboxListTile(
              value: widget.profile.goals.contains(g),
              title: Text(g),
              onChanged: (v) => setState(() {
                if (v == true) widget.profile.goals.add(g);
                else widget.profile.goals.remove(g);
              }),
            ),
          ),
          const SizedBox(height: 18),
          FilledButton(
            onPressed: () {
              if (widget.profile.goals.isEmpty) widget.profile.goals.add('Boards');
              widget.onChanged();
              Navigator.pop(context);
            },
            child: const Text('Save & Generate Suggestions'),
          ),
        ],
      ),
    );
  }
}

class SubjectSelectionPage extends StatefulWidget {
  const SubjectSelectionPage({super.key, required this.profile});
  final EducationProfile profile;
  @override
  State<SubjectSelectionPage> createState() => _SubjectSelectionPageState();
}

class _SubjectSelectionPageState extends State<SubjectSelectionPage> {
  late List<Subject> all;
  late Set<String> selected;

  @override
  void initState() {
    super.initState();
    all = SyllabusLibrary.allPossible(widget.profile);
    selected = widget.profile.selectedSubjects.map((s) => s.name).toSet();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Suggested Subjects')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Choose the subjects you want in your StudyMap.',
              style: TextStyle(fontSize: 16)),
          const SizedBox(height: 10),
          ...all.map(
            (subject) => Card(
              child: CheckboxListTile(
                value: selected.contains(subject.name),
                title: Text(subject.name),
                subtitle: Text('${subject.chapters.length} sample topics'),
                onChanged: (v) => setState(() {
                  if (v == true) selected.add(subject.name);
                  else selected.remove(subject.name);
                }),
              ),
            ),
          ),
          const SizedBox(height: 14),
          FilledButton(
            onPressed: () {
              widget.profile.selectedSubjects
                ..clear()
                ..addAll(all.where((s) => selected.contains(s.name)));
              Navigator.pop(context);
            },
            child: const Text('Save My Subjects'),
          ),
        ],
      ),
    );
  }
}

class SyllabusLibraryPage extends StatelessWidget {
  const SyllabusLibraryPage({super.key, required this.subjects});
  final List<Subject> subjects;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Syllabus Library')),
      body: subjects.isEmpty
          ? const Center(child: Text('No subjects selected yet.'))
          : ListView(
              padding: const EdgeInsets.all(16),
              children: subjects.map(
                (s) => Card(
                  child: ExpansionTile(
                    leading: const Icon(Icons.menu_book),
                    title: Text(s.name),
                    subtitle: Text('${s.chapters.length} starter topics'),
                    children: s.chapters
                        .map((c) => ListTile(
                              leading: const Icon(Icons.circle_outlined, size: 18),
                              title: Text(c),
                            ))
                        .toList(),
                  ),
                ),
              ).toList(),
            ),
    );
  }
}

class SyllabusLibrary {
  static List<Subject> suggest(EducationProfile p) {
    return allPossible(p);
  }

  static List<Subject> allPossible(EducationProfile p) {
    final result = <Subject>[];

    // Class/stream-based starter subjects.
    if (p.schoolClass <= 10) {
      result.addAll([
        Subject('English', ['Reading', 'Writing', 'Grammar', 'Literature']),
        Subject('Mathematics', ['Number System', 'Algebra', 'Geometry', 'Practice']),
        Subject('Science', ['Physics Basics', 'Chemistry Basics', 'Biology Basics']),
        Subject('Social Science', ['History', 'Geography', 'Civics', 'Economics']),
      ]);
    } else if (p.stream == 'Science') {
      result.addAll([
        Subject('Physics', ['Mechanics', 'Electricity', 'Waves', 'Modern Physics']),
        Subject('Chemistry', ['Physical Chemistry', 'Organic Chemistry', 'Inorganic Chemistry']),
        Subject('Mathematics', ['Algebra', 'Calculus', 'Coordinate Geometry']),
        Subject('Biology', ['Cell Biology', 'Human Physiology', 'Genetics', 'Ecology']),
      ]);
    } else if (p.stream == 'Commerce') {
      result.addAll([
        Subject('Accountancy', ['Accounting Basics', 'Partnership', 'Company Accounts']),
        Subject('Business Studies', ['Management', 'Marketing', 'Finance']),
        Subject('Economics', ['Microeconomics', 'Macroeconomics', 'Indian Economy']),
        Subject('English', ['Reading', 'Writing', 'Literature']),
      ]);
    } else {
      result.addAll([
        Subject('History', ['Ancient Themes', 'Medieval Themes', 'Modern India']),
        Subject('Political Science', ['Constitution', 'Politics', 'International Relations']),
        Subject('Geography', ['Physical Geography', 'Human Geography', 'Maps']),
        Subject('Economics', ['Microeconomics', 'Macroeconomics', 'Indian Economy']),
        Subject('English', ['Reading', 'Writing', 'Literature']),
        Subject('Sociology', ['Society', 'Social Change', 'Research']),
        Subject('Psychology', ['Introduction', 'Learning', 'Human Development']),
      ]);
    }

    // Competitive exam modules.
    if (p.goals.contains('JEE')) {
      result.addAll([
        Subject('JEE Physics', ['Mechanics', 'Electrodynamics', 'Thermodynamics']),
        Subject('JEE Chemistry', ['Physical', 'Organic', 'Inorganic']),
        Subject('JEE Mathematics', ['Algebra', 'Calculus', 'Coordinate Geometry']),
      ]);
    }

    if (p.goals.contains('NEET')) {
      result.addAll([
        Subject('NEET Physics', ['Mechanics', 'Electricity', 'Modern Physics']),
        Subject('NEET Chemistry', ['Physical', 'Organic', 'Inorganic']),
        Subject('NEET Biology', ['Botany', 'Zoology', 'Human Physiology']),
      ]);
    }

    if (p.goals.contains('CUET')) {
      result.addAll([
        Subject('CUET Language', ['Reading Comprehension', 'Vocabulary', 'Verbal Ability']),
        Subject('CUET General Test', ['General Knowledge', 'Current Affairs', 'Reasoning', 'Quantitative Ability']),
      ]);
    }

    if (p.goals.contains('CLAT')) {
      result.addAll([
        Subject('CLAT English', ['Comprehension', 'Vocabulary']),
        Subject('Legal Reasoning', ['Legal Principles', 'Legal Analysis']),
        Subject('Logical Reasoning', ['Arguments', 'Critical Reasoning']),
        Subject('Current Affairs & GK', ['National', 'International', 'Legal News']),
        Subject('Quantitative Techniques', ['Arithmetic', 'Data Interpretation']),
      ]);
    }

    // Remove duplicate names.
    final unique = <String, Subject>{};
    for (final s in result) {
      unique.putIfAbsent(s.name, () => s);
    }
    return unique.values.toList();
  }
}
