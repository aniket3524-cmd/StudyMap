# StudyMap V3 – Smart Study Roadmap

## New features
- Subject manager
- Chapter/topic manager
- Mark chapters completed
- Exam date selection
- Remaining days calculation
- Remaining syllabus calculation
- Automatic daily chapter target
- Smart Roadmap suggestions
- Advanced Study Rescue calculations

## How to run
Requires Flutter SDK and Android Studio or another Flutter environment.

Run:
flutter pub get
flutter run

## Note
This is a source-code project. Firebase, cloud sync, notifications, real syllabus database and AI are planned for later versions.
