import 'dart:async';
import 'package:flutter/material.dart';

void main() => runApp(const StudyMapApp());

class StudyMapApp extends StatelessWidget {
  const StudyMapApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'StudyMap',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      colorSchemeSeed: Colors.indigo,
      scaffoldBackgroundColor: const Color(0xFFF7F8FC),
    ),
    home: const AppShell(),
  );
}

class SubjectData {
  SubjectData(this.name, {List<ChapterData>? chapters})
      : chapters = chapters ?? [];
  String name;
  List<ChapterData> chapters;
}

class ChapterData {
  ChapterData(this.name, {this.done = false, this.minutes = 45});
  String name;
  bool done;
  int minutes;
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  DateTime examDate = DateTime.now().add(const Duration(days: 120));
  final subjects = <SubjectData>[
    SubjectData('Sample Subject', chapters: [
      ChapterData('Chapter 1', done: true),
      ChapterData('Chapter 2'),
      ChapterData('Chapter 3'),
    ]),
  ];

  int get totalChapters =>
      subjects.fold(0, (sum, s) => sum + s.chapters.length);
  int get completedChapters => subjects.fold(
      0, (sum, s) => sum + s.chapters.where((c) => c.done).length);
  int get remainingChapters => totalChapters - completedChapters;
  int get daysLeft {
    final today = DateTime.now();
    final a = DateTime(today.year, today.month, today.day);
    final b = DateTime(examDate.year, examDate.month, examDate.day);
    return b.difference(a).inDays.clamp(0, 9999);
  }

  double get dailyTarget =>
      daysLeft <= 0 ? remainingChapters.toDouble() : remainingChapters / daysLeft;

  @override
  Widget build(BuildContext context) {
    final pages = [
      RoadmapDashboard(
        subjects: subjects,
        examDate: examDate,
        daysLeft: daysLeft,
        total: totalChapters,
        completed: completedChapters,
        remaining: remainingChapters,
        dailyTarget: dailyTarget,
        onDateChanged: (date) => setState(() => examDate = date),
      ),
      SubjectManager(subjects: subjects, onChanged: () => setState(() {})),
      SmartPlanPage(
        subjects: subjects,
        daysLeft: daysLeft,
        dailyTarget: dailyTarget,
        remaining: remainingChapters,
      ),
      RescuePage(
        remaining: remainingChapters,
        daysLeft: daysLeft,
        onChanged: () => setState(() {}),
      ),
      ProgressPage(
        total: totalChapters,
        completed: completedChapters,
        daysLeft: daysLeft,
      ),
    ];

    return Scaffold(
      body: SafeArea(child: pages[_index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (v) => setState(() => _index = v),
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.home_outlined),
              selectedIcon: Icon(Icons.home),
              label: 'Home'),
          NavigationDestination(
              icon: Icon(Icons.menu_book_outlined),
              selectedIcon: Icon(Icons.menu_book),
              label: 'Subjects'),
          NavigationDestination(
              icon: Icon(Icons.map_outlined),
              selectedIcon: Icon(Icons.map),
              label: 'Roadmap'),
          NavigationDestination(
              icon: Icon(Icons.health_and_safety_outlined),
              selectedIcon: Icon(Icons.health_and_safety),
              label: 'Rescue'),
          NavigationDestination(
              icon: Icon(Icons.bar_chart_outlined),
              selectedIcon: Icon(Icons.bar_chart),
              label: 'Progress'),
        ],
      ),
    );
  }

  int _index = 0;
}

class RoadmapDashboard extends StatelessWidget {
  const RoadmapDashboard({
    super.key,
    required this.subjects,
    required this.examDate,
    required this.daysLeft,
    required this.total,
    required this.completed,
    required this.remaining,
    required this.dailyTarget,
    required this.onDateChanged,
  });

  final List<SubjectData> subjects;
  final DateTime examDate;
  final int daysLeft, total, completed, remaining;
  final double dailyTarget;
  final ValueChanged<DateTime> onDateChanged;

  @override
  Widget build(BuildContext context) {
    final progress = total == 0 ? 0.0 : completed / total;
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Your StudyMap 🗺️',
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        const Text('Your personal roadmap based on syllabus and exam date.'),
        const SizedBox(height: 18),
        Card(
          child: ListTile(
            leading: const Icon(Icons.calendar_month),
            title: const Text('Target Exam Date'),
            subtitle: Text(
                '${examDate.day.toString().padLeft(2, '0')}/${examDate.month.toString().padLeft(2, '0')}/${examDate.year}'),
            trailing: const Icon(Icons.edit),
            onTap: () async {
              final picked = await showDatePicker(
                context: context,
                initialDate: examDate,
                firstDate: DateTime.now(),
                lastDate: DateTime.now().add(const Duration(days: 3650)),
              );
              if (picked != null) onDateChanged(picked);
            },
          ),
        ),
        const SizedBox(height: 10),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            _metric(context, 'Days Left', '$daysLeft'),
            _metric(context, 'Total Chapters', '$total'),
            _metric(context, 'Completed', '$completed'),
            _metric(context, 'Remaining', '$remaining'),
          ],
        ),
        const SizedBox(height: 18),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Syllabus Progress',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
              const SizedBox(height: 12),
              LinearProgressIndicator(
                  value: progress,
                  minHeight: 12,
                  borderRadius: BorderRadius.circular(10)),
              const SizedBox(height: 8),
              Text('${(progress * 100).round()}% completed'),
            ]),
          ),
        ),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Today’s Smart Target 🎯',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 19)),
              const SizedBox(height: 8),
              Text(
                remaining == 0
                    ? 'Great! Your chapters are completed.'
                    : 'Complete at least ${dailyTarget.ceil()} chapter${dailyTarget.ceil() == 1 ? '' : 's'} per day to finish before your target date.',
                style: const TextStyle(fontSize: 16),
              ),
              const SizedBox(height: 8),
              const Text('StudyMap will later add revision and practice automatically.',
                  style: TextStyle(fontSize: 13)),
            ]),
          ),
        ),
      ],
    );
  }

  Widget _metric(BuildContext context, String title, String value) => SizedBox(
        width: (MediaQuery.of(context).size.width - 50) / 2,
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(children: [
              Text(value,
                  style: const TextStyle(
                      fontSize: 24, fontWeight: FontWeight.bold)),
              Text(title, textAlign: TextAlign.center),
            ]),
          ),
        ),
      );
}

class SubjectManager extends StatefulWidget {
  const SubjectManager(
      {super.key, required this.subjects, required this.onChanged});
  final List<SubjectData> subjects;
  final VoidCallback onChanged;
  @override
  State<SubjectManager> createState() => _SubjectManagerState();
}

class _SubjectManagerState extends State<SubjectManager> {
  void addSubject() {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add Subject'),
        content: TextField(
            controller: controller,
            autofocus: true,
            decoration: const InputDecoration(hintText: 'Example: Physics')),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          FilledButton(
            onPressed: () {
              if (controller.text.trim().isEmpty) return;
              setState(() =>
                  widget.subjects.add(SubjectData(controller.text.trim())));
              widget.onChanged();
              Navigator.pop(context);
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }

  void openSubject(SubjectData subject) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            ChapterManager(subject: subject, onChanged: widget.onChanged),
      ),
    ).then((_) {
      setState(() {});
      widget.onChanged();
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        floatingActionButton: FloatingActionButton.extended(
          onPressed: addSubject,
          icon: const Icon(Icons.add),
          label: const Text('Add Subject'),
        ),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text('Subjects 📚',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Text('Add your subjects and chapters.'),
            const SizedBox(height: 18),
            if (widget.subjects.isEmpty)
              const Center(
                  child: Padding(
                      padding: EdgeInsets.all(40),
                      child: Text('No subjects yet. Add your first subject.'))),
            ...widget.subjects.map((s) {
              final done = s.chapters.where((c) => c.done).length;
              return Card(
                child: ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.menu_book)),
                  title: Text(s.name),
                  subtitle: Text('$done/${s.chapters.length} chapters completed'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => openSubject(s),
                ),
              );
            }),
          ],
        ),
      );
}

class ChapterManager extends StatefulWidget {
  const ChapterManager(
      {super.key, required this.subject, required this.onChanged});
  final SubjectData subject;
  final VoidCallback onChanged;
  @override
  State<ChapterManager> createState() => _ChapterManagerState();
}

class _ChapterManagerState extends State<ChapterManager> {
  void addChapter() {
    final name = TextEditingController();
    final minutes = TextEditingController(text: '45');
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => Padding(
        padding: EdgeInsets.fromLTRB(
            20, 20, 20, MediaQuery.of(context).viewInsets.bottom + 20),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('Add Chapter • ${widget.subject.name}',
              style:
                  const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          TextField(
              controller: name,
              decoration: const InputDecoration(labelText: 'Chapter / Topic')),
          TextField(
              controller: minutes,
              keyboardType: TextInputType.number,
              decoration:
                  const InputDecoration(labelText: 'Estimated minutes')),
          const SizedBox(height: 14),
          FilledButton(
            onPressed: () {
              if (name.text.trim().isEmpty) return;
              setState(() => widget.subject.chapters.add(ChapterData(
                  name.text.trim(),
                  minutes: int.tryParse(minutes.text) ?? 45)));
              widget.onChanged();
              Navigator.pop(context);
            },
            child: const Text('Add Chapter'),
          ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.subject.name)),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: addChapter,
          icon: const Icon(Icons.add),
          label: const Text('Add Chapter'),
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            if (widget.subject.chapters.isEmpty)
              const Padding(
                padding: EdgeInsets.all(30),
                child: Text('No chapters yet. Add your syllabus topics.'),
              ),
            ...widget.subject.chapters.map((c) => Card(
                  child: CheckboxListTile(
                    value: c.done,
                    title: Text(c.name),
                    subtitle: Text('${c.minutes} min estimated'),
                    onChanged: (v) {
                      setState(() => c.done = v ?? false);
                      widget.onChanged();
                    },
                  ),
                )),
          ],
        ),
      );
}

class SmartPlanPage extends StatelessWidget {
  const SmartPlanPage({
    super.key,
    required this.subjects,
    required this.daysLeft,
    required this.dailyTarget,
    required this.remaining,
  });

  final List<SubjectData> subjects;
  final int daysLeft, remaining;
  final double dailyTarget;

  @override
  Widget build(BuildContext context) {
    final pending = <String>[];
    for (final s in subjects) {
      for (final c in s.chapters.where((c) => !c.done)) {
        pending.add('${s.name}: ${c.name}');
      }
    }
    final todayCount = dailyTarget.ceil().clamp(1, 10);
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Smart Roadmap 🤖',
            style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Text('$remaining chapters remaining • $daysLeft days left'),
        const SizedBox(height: 18),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Text(
              pending.isEmpty
                  ? 'No pending chapters. Add subjects and chapters or mark pending work.'
                  : 'Suggested target: $todayCount chapter${todayCount == 1 ? '' : 's'} today.',
              style: const TextStyle(
                  fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
        ),
        const SizedBox(height: 12),
        const Text('Suggested Next Chapters',
            style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        ...pending.take(todayCount).map((p) => Card(
              child: ListTile(
                leading: const Icon(Icons.auto_awesome),
                title: Text(p),
                subtitle: const Text('Priority task for your roadmap'),
              ),
            )),
        const SizedBox(height: 18),
        const Text('How it works',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const Text(
            'StudyMap divides your remaining syllabus by remaining days. In future versions, priority, revision, difficulty and exam weightage will also be used.'),
      ],
    );
  }
}

class RescuePage extends StatefulWidget {
  const RescuePage(
      {super.key,
      required this.remaining,
      required this.daysLeft,
      required this.onChanged});
  final int remaining, daysLeft;
  final VoidCallback onChanged;
  @override
  State<RescuePage> createState() => _RescuePageState();
}

class _RescuePageState extends State<RescuePage> {
  double missedDays = 3;
  double hours = 4;

  @override
  Widget build(BuildContext context) {
    final usableDays = (widget.daysLeft - missedDays.round()).clamp(1, 9999);
    final chaptersPerDay =
        widget.remaining == 0 ? 0 : (widget.remaining / usableDays).ceil();
    final capacity = hours.round() * 2;
    final realistic = chaptersPerDay <= capacity;

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Study Rescue 🆘',
            style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Don’t Restart. Recover your roadmap.'),
        const SizedBox(height: 22),
        Text('How many days did you miss? ${missedDays.round()}'),
        Slider(
            value: missedDays,
            min: 1,
            max: 30,
            divisions: 29,
            onChanged: (v) => setState(() => missedDays = v)),
        Text('Available study hours/day: ${hours.round()}'),
        Slider(
            value: hours,
            min: 1,
            max: 12,
            divisions: 11,
            onChanged: (v) => setState(() => hours = v)),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Updated Recovery Plan',
                  style: TextStyle(
                      fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              Text('Remaining chapters: ${widget.remaining}'),
              Text('Effective days left: $usableDays'),
              Text('New target: $chaptersPerDay chapter(s) per day'),
              Text('Daily capacity estimate: about $capacity study blocks'),
              const SizedBox(height: 10),
              Text(
                realistic
                    ? '✓ This target looks realistic. Start with priority chapters.'
                    : '⚠ This target may be difficult. Increase study time or extend your target date.',
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
            ]),
          ),
        ),
      ],
    );
  }
}

class ProgressPage extends StatelessWidget {
  const ProgressPage(
      {super.key,
      required this.total,
      required this.completed,
      required this.daysLeft});
  final int total, completed, daysLeft;

  @override
  Widget build(BuildContext context) {
    final progress = total == 0 ? 0.0 : completed / total;
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Progress 📊',
            style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
        const SizedBox(height: 20),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(children: [
              Text('${(progress * 100).round()}%',
                  style: const TextStyle(
                      fontSize: 42, fontWeight: FontWeight.bold)),
              const Text('Syllabus Completed'),
              const SizedBox(height: 10),
              LinearProgressIndicator(
                  value: progress,
                  minHeight: 10,
                  borderRadius: BorderRadius.circular(10)),
            ]),
          ),
        ),
        _card('Chapters Completed', '$completed / $total'),
        _card('Exam Countdown', '$daysLeft days left'),
        _card('Study Streak', 'Coming in next version'),
        _card('Study Hours', 'Timer analytics coming soon'),
      ],
    );
  }

  Widget _card(String a, String b) => Card(
        child: ListTile(
          title: Text(a),
          trailing:
              Text(b, style: const TextStyle(fontWeight: FontWeight.bold)),
        ),
      );
}
