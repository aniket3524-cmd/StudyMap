package com.studymap;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.accessibility.AccessibilityEvent;

import java.util.Collections;
import java.util.Set;

public class StudyMapAccessibilityService extends AccessibilityService {
    private static final String PREFS = "studymap_focus_lock";
    private long lastRedirect = 0L;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        // The service configuration is supplied by
        // res/xml/studymap_accessibility_service.xml.
        // Do not replace it with a new AccessibilityServiceInfo here;
        // Android can mark the service as malfunctioning if the runtime
        // configuration is inconsistent with the declared capabilities.
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;

        int type = event.getEventType();
        if (type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;

        CharSequence packageName = event.getPackageName();
        if (packageName == null) return;

        String pkg = packageName.toString();
        if (pkg.equals(getPackageName())) return;

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        long until = prefs.getLong("until", 0L);
        if (until <= System.currentTimeMillis()) return;

        Set<String> blocked = prefs.getStringSet(
                "packages", Collections.<String>emptySet());
        if (blocked == null || !blocked.contains(pkg)) return;

        long now = System.currentTimeMillis();
        if (now - lastRedirect < 1200L) return;
        lastRedirect = now;

        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_ACTIVITY_SINGLE_TOP
                        | Intent.FLAG_ACTIVITY_CLEAR_TOP
        );
        startActivity(intent);
    }

    @Override
    public void onInterrupt() {
        // Nothing to interrupt.
    }
}
