import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const StudyMapApp());
}

class StudentProfile {
  String name;
  int schoolClass;
  String? stream;
  List<String> goals;
  StudentProfile({required this.name, required this.schoolClass, this.stream, required this.goals});

  factory StudentProfile.fromMap(Map<String, dynamic> data) => StudentProfile(
        name: (data['name'] ?? 'Student').toString(),
        schoolClass: (data['schoolClass'] as num?)?.toInt() ?? 12,
        stream: data['stream'] as String?,
        goals: List<String>.from(data['goals'] ?? const []),
      );

  Map<String, dynamic> toMap() => {
        'name': name,
        'schoolClass': schoolClass,
        'stream': stream,
        'goals': goals,
        'profileComplete': true,
        'updatedAt': FieldValue.serverTimestamp(),
      };
}

class StudyMapApp extends StatelessWidget {
  const StudyMapApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'StudyMap',
        theme: ThemeData(
          useMaterial3: true,
          colorSchemeSeed: Colors.indigo,
          scaffoldBackgroundColor: const Color(0xFFF7F8FC),
        ),
        home: const AuthGate(),
      );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, auth) {
          if (auth.connectionState == ConnectionState.waiting) {
            return const Scaffold(body: Center(child: CircularProgressIndicator()));
          }
          if (!auth.hasData) return const WelcomeScreen();
          final user = auth.data!;
          return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
            stream: FirebaseFirestore.instance.collection('users').doc(user.uid).snapshots(),
            builder: (context, snap) {
              if (snap.connectionState == ConnectionState.waiting) {
                return const Scaffold(body: Center(child: CircularProgressIndicator()));
              }
              final data = snap.data?.data() ?? <String, dynamic>{};
              if (data['profileComplete'] != true) {
                return ProfileSetup(
                  initialName: (data['name'] ?? user.displayName ?? 'Student').toString(),
                );
              }
              return AppShell(profile: StudentProfile.fromMap(data));
            },
          );
        },
      );
}

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.map_outlined, size: 90),
              const SizedBox(height: 20),
              const Text('StudyMap', style: TextStyle(fontSize: 38, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              const Text('Your smart study planning app'),
              const SizedBox(height: 30),
              SizedBox(width: double.infinity, child: FilledButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginScreen())), child: const Text('Login'))),
              TextButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SignupScreen())), child: const Text('Create Account')),
            ]),
          ),
        ),
      );
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override State<LoginScreen> createState() => _LoginScreenState();
}
class _LoginScreenState extends State<LoginScreen> {
  final email = TextEditingController(), password = TextEditingController();
  bool loading = false;
  Future<void> login() async {
    if (email.text.trim().isEmpty || password.text.isEmpty) return;
    setState(() => loading = true);
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(email: email.text.trim(), password: password.text);
      if (mounted) Navigator.popUntil(context, (r) => r.isFirst);
    } on FirebaseAuthException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? 'Login failed')));
    } finally { if (mounted) setState(() => loading = false); }
  }
  @override void dispose() { email.dispose(); password.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(), body: ListView(padding: const EdgeInsets.all(24), children: [
    const Text('Login', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)), const SizedBox(height: 24),
    TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder())), const SizedBox(height: 14),
    TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Password', border: OutlineInputBorder())), const SizedBox(height: 20),
    FilledButton(onPressed: loading ? null : login, child: Text(loading ? 'Please wait...' : 'Login')),
  ]));
}

class SignupScreen extends StatefulWidget { const SignupScreen({super.key}); @override State<SignupScreen> createState() => _SignupScreenState(); }
class _SignupScreenState extends State<SignupScreen> {
  final name = TextEditingController(), email = TextEditingController(), password = TextEditingController(); bool loading = false;
  Future<void> signup() async {
    if (name.text.trim().isEmpty || email.text.trim().isEmpty || password.text.length < 6) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Fill all fields. Password must be at least 6 characters.'))); return;
    }
    setState(() => loading = true);
    try {
      final c = await FirebaseAuth.instance.createUserWithEmailAndPassword(email: email.text.trim(), password: password.text);
      await FirebaseFirestore.instance.collection('users').doc(c.user!.uid).set({'name': name.text.trim(), 'email': email.text.trim(), 'createdAt': FieldValue.serverTimestamp()}, SetOptions(merge: true));
      if (mounted) Navigator.popUntil(context, (r) => r.isFirst);
    } on FirebaseAuthException catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? 'Signup failed'))); }
    finally { if (mounted) setState(() => loading = false); }
  }
  @override void dispose() { name.dispose(); email.dispose(); password.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(), body: ListView(padding: const EdgeInsets.all(24), children: [
    const Text('Create Account', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)), const SizedBox(height: 24),
    TextField(controller: name, decoration: const InputDecoration(labelText: 'Full Name', border: OutlineInputBorder())), const SizedBox(height: 14),
    TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder())), const SizedBox(height: 14),
    TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Password (minimum 6 characters)', border: OutlineInputBorder())), const SizedBox(height: 20),
    FilledButton(onPressed: loading ? null : signup, child: Text(loading ? 'Please wait...' : 'Create Account')),
  ]));
}

class ProfileSetup extends StatefulWidget { const ProfileSetup({super.key, required this.initialName}); final String initialName; @override State<ProfileSetup> createState() => _ProfileSetupState(); }
class _ProfileSetupState extends State<ProfileSetup> {
  int step = 0; late final TextEditingController nameController; int selectedClass = 12; String? stream; final goals = <String>{};
  final goalOptions = const ['Boards', 'JEE', 'NEET', 'CUET', 'CLAT', 'School Exams']; bool saving = false;
  @override void initState() { super.initState(); nameController = TextEditingController(text: widget.initialName); }
  @override void dispose() { nameController.dispose(); super.dispose(); }
  Future<void> next() async {
    if (step == 0 && nameController.text.trim().isEmpty) return;
    if (step == 2 && (selectedClass == 11 || selectedClass == 12) && stream == null) return;
    if (step == 3 && goals.isEmpty) return;
    if (step < 3) { setState(() => step++); return; }
    setState(() => saving = true);
    final uid = FirebaseAuth.instance.currentUser!.uid;
    await FirebaseFirestore.instance.collection('users').doc(uid).set(StudentProfile(name: nameController.text.trim(), schoolClass: selectedClass, stream: (selectedClass == 11 || selectedClass == 12) ? stream : null, goals: goals.toList()).toMap(), SetOptions(merge: true));
    if (mounted) setState(() => saving = false);
  }
  @override Widget build(BuildContext context) {
    final titles = ['Welcome to StudyMap', 'Choose Your Class', 'Choose Your Stream', 'Your Study Goals'];
    return Scaffold(body: SafeArea(child: Padding(padding: const EdgeInsets.all(24), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      LinearProgressIndicator(value: (step + 1) / 4, borderRadius: BorderRadius.circular(8)), const SizedBox(height: 32),
      Text(titles[step], style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold)), const SizedBox(height: 8),
      Text(step == 0 ? 'Let’s build your personal study journey.' : 'StudyMap will personalize your roadmap based on your choices.'), const SizedBox(height: 28), Expanded(child: _stepContent()),
      Row(children: [if (step > 0) TextButton(onPressed: saving ? null : () => setState(() => step--), child: const Text('Back')), const Spacer(), FilledButton(onPressed: saving ? null : next, child: Text(saving ? 'Saving...' : step == 3 ? 'Start My Journey' : 'Continue'))])
    ])));
  }
  Widget _stepContent() {
    if (step == 0) return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('What should we call you?', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)), const SizedBox(height: 12), TextField(controller: nameController, decoration: const InputDecoration(labelText: 'Your Name', border: OutlineInputBorder(), prefixIcon: Icon(Icons.person)))]);
    if (step == 1) return GridView.count(crossAxisCount: 3, childAspectRatio: 1.25, crossAxisSpacing: 10, mainAxisSpacing: 10, children: List.generate(12, (i) { final c = i + 1; final selected = selectedClass == c; return InkWell(onTap: () => setState(() => selectedClass = c), child: Card(color: selected ? Theme.of(context).colorScheme.primaryContainer : null, child: Center(child: Text('Class $c', style: const TextStyle(fontWeight: FontWeight.bold))))); }));
    if (step == 2) { if (selectedClass != 11 && selectedClass != 12) return const Center(child: Text('Stream selection is needed only for Class 11 and 12.\nTap Continue.', textAlign: TextAlign.center)); return ListView(children: ['Science','Commerce','Humanities'].map((s) => Card(child: RadioListTile<String>(value: s, groupValue: stream, title: Text(s), onChanged: (v) => setState(() => stream = v)))).toList()); }
    return ListView(children: [const Text('You can select multiple goals.'), const SizedBox(height: 12), ...goalOptions.map((g) => Card(child: CheckboxListTile(value: goals.contains(g), title: Text(g), onChanged: (v) => setState(() => v == true ? goals.add(g) : goals.remove(g))))]);
  }
}

class AppShell extends StatefulWidget { const AppShell({super.key, required this.profile}); final StudentProfile profile; @override State<AppShell> createState() => _AppShellState(); }
class _AppShellState extends State<AppShell> {
  int index = 0; late StudentProfile profile;
  final tasks = <StudyTask>[StudyTask('Welcome Task', 'Create your first study plan', 20), StudyTask('Focus', 'Complete one important topic', 45)];
  @override void initState() { super.initState(); profile = widget.profile; }
  Future<void> saveProfile(StudentProfile value) async { await FirebaseFirestore.instance.collection('users').doc(FirebaseAuth.instance.currentUser!.uid).set(value.toMap(), SetOptions(merge: true)); if (mounted) setState(() => profile = value); }
  @override Widget build(BuildContext context) {
    final pages = [HomePage(profile: profile, tasks: tasks, refresh: () => setState(() {}), onOpenPlanner: () => setState(() => index = 1), onOpenProgress: () => setState(() => index = 3)), PlannerPage(tasks: tasks, refresh: () => setState(() {})), const RescuePage(), ProgressPage(tasks: tasks), ProfilePage(profile: profile, onSave: saveProfile)];
    return Scaffold(appBar: AppBar(title: const Text('StudyMap'), actions: [IconButton(onPressed: () => FirebaseAuth.instance.signOut(), icon: const Icon(Icons.logout))]), body: SafeArea(child: pages[index]), bottomNavigationBar: NavigationBar(selectedIndex: index, onDestinationSelected: (v) => setState(() => index = v), destinations: const [NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'), NavigationDestination(icon: Icon(Icons.map_outlined), selectedIcon: Icon(Icons.map), label: 'Roadmap'), NavigationDestination(icon: Icon(Icons.health_and_safety_outlined), selectedIcon: Icon(Icons.health_and_safety), label: 'Rescue'), NavigationDestination(icon: Icon(Icons.bar_chart_outlined), selectedIcon: Icon(Icons.bar_chart), label: 'Progress'), NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile')]));
  }
}

class StudyTask { StudyTask(this.subject, this.title, this.minutes, {this.done = false}); final String subject; final String title; final int minutes; bool done; }

class HomePage extends StatelessWidget {
  const HomePage({super.key, required this.profile, required this.tasks, required this.refresh, required this.onOpenPlanner, required this.onOpenProgress});
  final StudentProfile profile; final List<StudyTask> tasks; final VoidCallback refresh, onOpenPlanner, onOpenProgress;
  @override Widget build(BuildContext context) { final done = tasks.where((t) => t.done).length; final progress = tasks.isEmpty ? 0.0 : done / tasks.length; return ListView(padding: const EdgeInsets.all(20), children: [
    Text('Hello, ${profile.name} 👋', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold)), const SizedBox(height: 6), Text('Class ${profile.schoolClass}${profile.stream == null ? '' : ' • ${profile.stream}'}'), const SizedBox(height: 18),
    Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Today’s Progress', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)), const SizedBox(height: 12), LinearProgressIndicator(value: progress, minHeight: 10, borderRadius: BorderRadius.circular(10)), const SizedBox(height: 8), Text('$done of ${tasks.length} tasks completed')])),
    const SizedBox(height: 16),
    Card(child: ListTile(leading: const Icon(Icons.menu_book_outlined), title: const Text('Auto Syllabus'), subtitle: const Text('Your subjects and goals'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SyllabusPage(profile: profile)))),
    Card(child: ListTile(leading: const Icon(Icons.map_outlined), title: const Text('Smart Roadmap'), subtitle: const Text('Add and manage study tasks'), onTap: onOpenPlanner)),
    Card(child: ListTile(leading: const Icon(Icons.calendar_month_outlined), title: const Text('Smart Timetable'), subtitle: const Text('Suggested daily study routine'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => TimetablePage(tasks: tasks)))),
    Card(child: ListTile(leading: const Icon(Icons.bar_chart_outlined), title: const Text('Progress'), subtitle: const Text('Track completed tasks'), onTap: onOpenProgress)),
    const SizedBox(height: 12), const FocusTimer(),
  ]); }
}

class SyllabusPage extends StatelessWidget { const SyllabusPage({super.key, required this.profile}); final StudentProfile profile; @override Widget build(BuildContext context) { final subjects = profile.stream == 'Humanities' ? ['History','Political Science','Economics','English'] : profile.stream == 'Science' ? ['Physics','Chemistry','Mathematics / Biology','English'] : profile.stream == 'Commerce' ? ['Accountancy','Business Studies','Economics','English'] : ['English','Mathematics','Science','Social Science']; return Scaffold(appBar: AppBar(title: const Text('Auto Syllabus')), body: ListView(padding: const EdgeInsets.all(20), children: [Text('Class ${profile.schoolClass}${profile.stream == null ? '' : ' • ${profile.stream}'}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), const SizedBox(height: 10), Text('Goals: ${profile.goals.join(', ')}'), const SizedBox(height: 20), ...subjects.map((s) => Card(child: ListTile(leading: const Icon(Icons.menu_book), title: Text(s), subtitle: const Text('Add topics in Smart Roadmap'))))])); } }

class TimetablePage extends StatelessWidget { const TimetablePage({super.key, required this.tasks}); final List<StudyTask> tasks; @override Widget build(BuildContext context) { return Scaffold(appBar: AppBar(title: const Text('Smart Timetable')), body: ListView(padding: const EdgeInsets.all(20), children: [const Text('Suggested routine', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), const SizedBox(height: 12), _slot('Morning', '45 min — Difficult topic'), _slot('Afternoon', '30 min — Practice / homework'), _slot('Evening', '45 min — Current roadmap task'), const SizedBox(height: 12), const Text('Your tasks', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), ...tasks.map((t) => Card(child: ListTile(title: Text(t.title), subtitle: Text('${t.subject} • ${t.minutes} min'))))])); } Widget _slot(String a, String b) => Card(child: ListTile(leading: const Icon(Icons.schedule), title: Text(a), subtitle: Text(b))); }

class PlannerPage extends StatefulWidget { const PlannerPage({super.key, required this.tasks, required this.refresh}); final List<StudyTask> tasks; final VoidCallback refresh; @override State<PlannerPage> createState() => _PlannerPageState(); }
class _PlannerPageState extends State<PlannerPage> {
  void addTask() { final subject = TextEditingController(); final title = TextEditingController(); final mins = TextEditingController(text: '30'); showModalBottomSheet(context: context, isScrollControlled: true, builder: (context) => Padding(padding: EdgeInsets.fromLTRB(20,20,20,MediaQuery.of(context).viewInsets.bottom+20), child: Column(mainAxisSize: MainAxisSize.min, children: [const Text('Add Study Task', style: TextStyle(fontSize: 22,fontWeight: FontWeight.bold)), TextField(controller: subject, decoration: const InputDecoration(labelText:'Subject')), TextField(controller:title, decoration: const InputDecoration(labelText:'Topic / Task')), TextField(controller:mins, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText:'Minutes')), const SizedBox(height:12), FilledButton(onPressed:(){ if(subject.text.trim().isEmpty||title.text.trim().isEmpty)return; setState(()=>widget.tasks.add(StudyTask(subject.text.trim(),title.text.trim(),int.tryParse(mins.text)??30))); widget.refresh(); Navigator.pop(context);}, child:const Text('Save Task'))]))); }
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [const Text('Smart Roadmap 🗺️', style: TextStyle(fontSize:26,fontWeight:FontWeight.bold)), const SizedBox(height:8), const Text('Build your personal daily study plan.'), const SizedBox(height:16), ...widget.tasks.map((t)=>Card(child:CheckboxListTile(value:t.done,title:Text(t.title),subtitle:Text('${t.subject} • ${t.minutes} min'),onChanged:(v){setState(()=>t.done=v??false);widget.refresh();}))), const SizedBox(height:12), FilledButton.icon(onPressed:addTask,icon:const Icon(Icons.add),label:const Text('Add Study Task'))]);
}

class RescuePage extends StatefulWidget { const RescuePage({super.key}); @override State<RescuePage> createState()=>_RescuePageState(); }
class _RescuePageState extends State<RescuePage> { double missed=3,hours=4; @override Widget build(BuildContext context){ final taskCount=(missed*2/hours).ceil().clamp(1,8); return ListView(padding:const EdgeInsets.all(20),children:[const Text('Study Rescue 🆘',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),const SizedBox(height:8),const Text('Don’t Restart. Recover.'),const SizedBox(height:24),Text('Missed study days: ${missed.round()}'),Slider(value:missed,min:1,max:30,divisions:29,onChanged:(v)=>setState(()=>missed=v)),Text('Available hours/day: ${hours.round()}'),Slider(value:hours,min:1,max:12,divisions:11,onChanged:(v)=>setState(()=>hours=v)),Card(child:Padding(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Recovery Plan',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const SizedBox(height:10),Text('Day 1: $taskCount priority tasks'),Text('Day 2: $taskCount priority tasks + revision'),const Text('Day 3: Light revision + practice'),const SizedBox(height:8),const Text('Small steps. Back on track.',style:TextStyle(fontWeight:FontWeight.w600))]))]); } }

class ProgressPage extends StatelessWidget { const ProgressPage({super.key, required this.tasks}); final List<StudyTask> tasks; @override Widget build(BuildContext context){ final done=tasks.where((e)=>e.done).length; final totalMinutes=tasks.where((e)=>e.done).fold<int>(0,(sum,t)=>sum+t.minutes); return ListView(padding:const EdgeInsets.all(20),children:[const Text('Progress 📊',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),const SizedBox(height:18),_card('Completed Tasks','$done / ${tasks.length}'),_card('Study Time','$totalMinutes min'),_card('Completion Rate',tasks.isEmpty?'0%':'${((done/tasks.length)*100).round()}%'),_card('Next Goal','Keep completing your roadmap')]); } Widget _card(String a,String b)=>Card(child:ListTile(title:Text(a),trailing:Text(b,style:const TextStyle(fontWeight:FontWeight.bold)))); }

class ProfilePage extends StatefulWidget { const ProfilePage({super.key,required this.profile,required this.onSave}); final StudentProfile profile; final ValueChanged<StudentProfile> onSave; @override State<ProfilePage> createState()=>_ProfilePageState(); }
class _ProfilePageState extends State<ProfilePage>{ late TextEditingController name; @override void initState(){super.initState();name=TextEditingController(text:widget.profile.name);} @override void dispose(){name.dispose();super.dispose();} @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(20),children:[const Center(child:CircleAvatar(radius:42,child:Icon(Icons.person,size:44))),const SizedBox(height:12),const Center(child:Text('Student Profile',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold))),const SizedBox(height:24),TextField(controller:name,decoration:const InputDecoration(labelText:'Name',border:OutlineInputBorder())),const SizedBox(height:14),ListTile(leading:const Icon(Icons.school),title:const Text('Class'),trailing:Text('Class ${widget.profile.schoolClass}')),if(widget.profile.stream!=null)ListTile(leading:const Icon(Icons.account_tree),title:const Text('Stream'),trailing:Text(widget.profile.stream!)),ListTile(leading:const Icon(Icons.flag_outlined),title:const Text('Goals'),subtitle:Text(widget.profile.goals.join(', '))),const SizedBox(height:12),FilledButton(onPressed:(){final updated=StudentProfile(name:name.text.trim().isEmpty?widget.profile.name:name.text.trim(),schoolClass:widget.profile.schoolClass,stream:widget.profile.stream,goals:widget.profile.goals);widget.onSave(updated);ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Profile saved successfully')));},child:const Text('Save Profile'))]); }

class FocusTimer extends StatefulWidget { const FocusTimer({super.key}); @override State<FocusTimer> createState()=>_FocusTimerState(); }
class _FocusTimerState extends State<FocusTimer>{ int seconds=25*60; Timer? timer; bool running=false; void toggle(){if(running){timer?.cancel();setState(()=>running=false);}else{setState(()=>running=true);timer=Timer.periodic(const Duration(seconds:1),(_){if(seconds<=0){timer?.cancel();setState(()=>running=false);}else{setState(()=>seconds--);}});}} @override void dispose(){timer?.cancel();super.dispose();} @override Widget build(BuildContext context){final m=(seconds~/60).toString().padLeft(2,'0');final s=(seconds%60).toString().padLeft(2,'0');return Card(child:Padding(padding:const EdgeInsets.all(20),child:Column(children:[const Text('Focus Timer ⏱️',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),const SizedBox(height:8),Text('$m:$s',style:const TextStyle(fontSize:40,fontWeight:FontWeight.bold)),FilledButton(onPressed:toggle,child:Text(running?'Pause':'Start Focus'))])));}}
