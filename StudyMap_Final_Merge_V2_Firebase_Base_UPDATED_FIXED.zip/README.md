# StudyMap Final Working Merge
Firebase Login + Create Account + Profile Setup + Auto Syllabus + Smart Roadmap + Smart Timetable + Rescue + Progress + Focus Timer.
