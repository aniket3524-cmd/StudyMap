# StudyMap V5 – Smart Timetable Generator

## New Features
- Wake-up and sleep time setup
- Busy time / school / coaching block
- Daily study target
- Preferred study session duration
- Subject priority system
- Automatic timetable generation
- Focus sessions and breaks
- Today's schedule with completion tracking
- Schedule Rescue / recovery timetable

## Prototype Note
This version uses an on-device scheduling algorithm for demonstration.
Future versions can combine syllabus deadlines, chapter difficulty, exam dates,
missed tasks, revision cycles and notifications.

## Run
Requires a Flutter development environment:
flutter pub get
flutter run
