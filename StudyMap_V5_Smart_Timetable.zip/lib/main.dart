import 'package:flutter/material.dart';

void main() => runApp(const StudyMapApp());

class StudyMapApp extends StatelessWidget {
  const StudyMapApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'StudyMap V5',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorSchemeSeed: Colors.indigo,
          scaffoldBackgroundColor: const Color(0xFFF7F8FC),
        ),
        home: const AppShell(),
      );
}

class SubjectItem {
  SubjectItem(this.name, {this.priority = 3});
  final String name;
  int priority;
}

class RoutineSettings {
  TimeOfDay wake = const TimeOfDay(hour: 6, minute: 0);
  TimeOfDay sleep = const TimeOfDay(hour: 22, minute: 30);
  TimeOfDay busyStart = const TimeOfDay(hour: 8, minute: 0);
  TimeOfDay busyEnd = const TimeOfDay(hour: 15, minute: 0);
  int targetStudyMinutes = 240;
  int sessionMinutes = 60;
}

class StudySession {
  StudySession({
    required this.start,
    required this.end,
    required this.subject,
    required this.type,
    this.done = false,
  });
  final TimeOfDay start;
  final TimeOfDay end;
  final String subject;
  final String type;
  bool done;
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  final settings = RoutineSettings();
  final subjects = [
    SubjectItem('History', priority: 4),
    SubjectItem('Political Science', priority: 5),
    SubjectItem('Economics', priority: 4),
    SubjectItem('English', priority: 2),
  ];
  List<StudySession> schedule = [];

  @override
  void initState() {
    super.initState();
    schedule = SmartScheduler.generate(settings, subjects);
  }

  void regenerate() {
    setState(() => schedule = SmartScheduler.generate(settings, subjects));
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      DashboardPage(
        settings: settings,
        schedule: schedule,
        onRegenerate: regenerate,
      ),
      TimetableSetupPage(
        settings: settings,
        onChanged: regenerate,
      ),
      SubjectsPage(
        subjects: subjects,
        onChanged: regenerate,
      ),
      TodaySchedulePage(
        schedule: schedule,
        onChanged: () => setState(() {}),
      ),
      RescueSchedulePage(
        settings: settings,
        schedule: schedule,
        subjects: subjects,
        onRecovered: (newSchedule) => setState(() => schedule = newSchedule),
      ),
    ];

    return Scaffold(
      body: SafeArea(child: pages[_index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.settings_outlined),
            selectedIcon: Icon(Icons.settings),
            label: 'Setup',
          ),
          NavigationDestination(
            icon: Icon(Icons.menu_book_outlined),
            selectedIcon: Icon(Icons.menu_book),
            label: 'Subjects',
          ),
          NavigationDestination(
            icon: Icon(Icons.calendar_today_outlined),
            selectedIcon: Icon(Icons.calendar_today),
            label: 'Schedule',
          ),
          NavigationDestination(
            icon: Icon(Icons.health_and_safety_outlined),
            selectedIcon: Icon(Icons.health_and_safety),
            label: 'Rescue',
          ),
        ],
      ),
    );
  }

  int _index = 0;
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({
    super.key,
    required this.settings,
    required this.schedule,
    required this.onRegenerate,
  });

  final RoutineSettings settings;
  final List<StudySession> schedule;
  final VoidCallback onRegenerate;

  @override
  Widget build(BuildContext context) {
    final completed = schedule.where((s) => s.done).length;
    final totalMinutes = schedule.fold<int>(
      0,
      (sum, s) => sum + _minutesBetween(s.start, s.end),
    );
    final progress = schedule.isEmpty ? 0.0 : completed / schedule.length;

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text(
          'Smart Timetable 📅',
          style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 6),
        const Text('Your study routine, automatically planned around your day.'),
        const SizedBox(height: 18),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Today’s Progress',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                LinearProgressIndicator(
                  value: progress,
                  minHeight: 11,
                  borderRadius: BorderRadius.circular(10),
                ),
                const SizedBox(height: 8),
                Text('$completed of ${schedule.length} sessions completed'),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            _metric('Study Time', '${(totalMinutes / 60).toStringAsFixed(1)}h'),
            _metric('Sessions', '${schedule.length}'),
            _metric('Target', '${settings.targetStudyMinutes ~/ 60}h'),
            _metric('Session', '${settings.sessionMinutes}m'),
          ],
        ),
        const SizedBox(height: 20),
        const Text('Quick Preview',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        ...schedule.take(3).map(
              (s) => Card(
                child: ListTile(
                  leading: Icon(_iconForType(s.type)),
                  title: Text(s.subject),
                  subtitle: Text('${_format(s.start)} – ${_format(s.end)} • ${s.type}'),
                ),
              ),
            ),
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: onRegenerate,
          icon: const Icon(Icons.auto_awesome),
          label: const Text('Regenerate My Timetable'),
        ),
      ],
    );
  }

  Widget _metric(String label, String value) => SizedBox(
        width: 165,
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              children: [
                Text(value,
                    style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
                Text(label),
              ],
            ),
          ),
        ),
      );
}

class TimetableSetupPage extends StatefulWidget {
  const TimetableSetupPage({
    super.key,
    required this.settings,
    required this.onChanged,
  });
  final RoutineSettings settings;
  final VoidCallback onChanged;

  @override
  State<TimetableSetupPage> createState() => _TimetableSetupPageState();
}

class _TimetableSetupPageState extends State<TimetableSetupPage> {
  Future<void> pickTime(
    String type,
    TimeOfDay initial,
    void Function(TimeOfDay) save,
  ) async {
    final value = await showTimePicker(context: context, initialTime: initial);
    if (value != null) {
      setState(() => save(value));
      widget.onChanged();
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.settings;
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Daily Routine Setup ⚙️',
            style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Tell StudyMap about your daily routine.'),
        const SizedBox(height: 16),
        _timeTile(
          'Wake-up Time',
          s.wake,
          Icons.wb_sunny_outlined,
          () => pickTime('wake', s.wake, (v) => s.wake = v),
        ),
        _timeTile(
          'Busy Time Start',
          s.busyStart,
          Icons.school_outlined,
          () => pickTime('busy start', s.busyStart, (v) => s.busyStart = v),
        ),
        _timeTile(
          'Busy Time End',
          s.busyEnd,
          Icons.schedule,
          () => pickTime('busy end', s.busyEnd, (v) => s.busyEnd = v),
        ),
        _timeTile(
          'Sleep Time',
          s.sleep,
          Icons.bedtime_outlined,
          () => pickTime('sleep', s.sleep, (v) => s.sleep = v),
        ),
        const SizedBox(height: 18),
        Text('Daily study target: ${s.targetStudyMinutes ~/ 60}h ${s.targetStudyMinutes % 60}m'),
        Slider(
          value: s.targetStudyMinutes.toDouble(),
          min: 60,
          max: 600,
          divisions: 18,
          label: '${s.targetStudyMinutes} min',
          onChanged: (v) {
            setState(() => s.targetStudyMinutes = v.round());
            widget.onChanged();
          },
        ),
        const SizedBox(height: 10),
        Text('Preferred session length: ${s.sessionMinutes} minutes'),
        Wrap(
          spacing: 8,
          children: [30, 45, 60, 90, 120]
              .map(
                (m) => ChoiceChip(
                  label: Text('$m min'),
                  selected: s.sessionMinutes == m,
                  onSelected: (_) {
                    setState(() => s.sessionMinutes = m);
                    widget.onChanged();
                  },
                ),
              )
              .toList(),
        ),
        const SizedBox(height: 20),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              'Tip: Busy time can be school, coaching, work or any fixed activity. '
              'StudyMap will avoid this time while generating sessions.',
              style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
            ),
          ),
        ),
      ],
    );
  }

  Widget _timeTile(String title, TimeOfDay time, IconData icon, VoidCallback onTap) {
    return Card(
      child: ListTile(
        leading: Icon(icon),
        title: Text(title),
        trailing: Text(
          _format(time),
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        onTap: onTap,
      ),
    );
  }
}

class SubjectsPage extends StatefulWidget {
  const SubjectsPage({
    super.key,
    required this.subjects,
    required this.onChanged,
  });
  final List<SubjectItem> subjects;
  final VoidCallback onChanged;

  @override
  State<SubjectsPage> createState() => _SubjectsPageState();
}

class _SubjectsPageState extends State<SubjectsPage> {
  void addSubject() {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add Subject'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'Example: Geography'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              if (controller.text.trim().isEmpty) return;
              setState(() => widget.subjects.add(SubjectItem(controller.text.trim())));
              widget.onChanged();
              Navigator.pop(context);
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        onPressed: addSubject,
        icon: const Icon(Icons.add),
        label: const Text('Add Subject'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('Subjects & Priority 📚',
              style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('Higher priority subjects get more frequent timetable slots.'),
          const SizedBox(height: 14),
          ...widget.subjects.asMap().entries.map((entry) {
            final index = entry.key;
            final subject = entry.value;
            return Card(
              child: ListTile(
                leading: const CircleAvatar(child: Icon(Icons.book)),
                title: Text(subject.name),
                subtitle: Text('Priority: ${subject.priority}/5'),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.remove),
                      onPressed: subject.priority <= 1
                          ? null
                          : () {
                              setState(() => subject.priority--);
                              widget.onChanged();
                            },
                    ),
                    IconButton(
                      icon: const Icon(Icons.add),
                      onPressed: subject.priority >= 5
                          ? null
                          : () {
                              setState(() => subject.priority++);
                              widget.onChanged();
                            },
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () {
                        setState(() => widget.subjects.removeAt(index));
                        widget.onChanged();
                      },
                    ),
                  ],
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}

class TodaySchedulePage extends StatelessWidget {
  const TodaySchedulePage({
    super.key,
    required this.schedule,
    required this.onChanged,
  });
  final List<StudySession> schedule;
  final VoidCallback onChanged;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Today’s Schedule 🗓️',
            style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Mark sessions complete as you finish them.'),
        const SizedBox(height: 18),
        if (schedule.isEmpty)
          const Card(
            child: Padding(
              padding: EdgeInsets.all(20),
              child: Text('No sessions generated. Check your routine setup.'),
            ),
          ),
        ...schedule.map(
          (s) => Card(
            child: CheckboxListTile(
              value: s.done,
              onChanged: (v) {
                s.done = v ?? false;
                onChanged();
              },
              secondary: Icon(_iconForType(s.type)),
              title: Text(s.subject),
              subtitle: Text('${_format(s.start)} – ${_format(s.end)} • ${s.type}'),
            ),
          ),
        ),
      ],
    );
  }
}

class RescueSchedulePage extends StatefulWidget {
  const RescueSchedulePage({
    super.key,
    required this.settings,
    required this.schedule,
    required this.subjects,
    required this.onRecovered,
  });
  final RoutineSettings settings;
  final List<StudySession> schedule;
  final List<SubjectItem> subjects;
  final ValueChanged<List<StudySession>> onRecovered;

  @override
  State<RescueSchedulePage> createState() => _RescueSchedulePageState();
}

class _RescueSchedulePageState extends State<RescueSchedulePage> {
  double missed = 1;

  @override
  Widget build(BuildContext context) {
    final missedSessions = widget.schedule.where((s) => !s.done).length;
    final newTarget = (widget.settings.targetStudyMinutes + missedSessions * 15)
        .clamp(60, 600);

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Schedule Rescue 🆘',
            style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Missed your plan? StudyMap can rebalance your day.'),
        const SizedBox(height: 20),
        Text('Missed study days: ${missed.round()}'),
        Slider(
          value: missed,
          min: 1,
          max: 7,
          divisions: 6,
          onChanged: (v) => setState(() => missed = v),
        ),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Recovery Suggestion',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                Text('Uncompleted sessions: $missedSessions'),
                Text('Suggested temporary daily target: ${newTarget ~/ 60}h ${newTarget % 60}m'),
                const SizedBox(height: 8),
                const Text(
                  'The generator rotates subjects by priority and places sessions outside busy hours.',
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        FilledButton.icon(
          onPressed: () {
            final old = widget.settings.targetStudyMinutes;
            widget.settings.targetStudyMinutes = newTarget;
            final updated = SmartScheduler.generate(widget.settings, widget.subjects);
            widget.settings.targetStudyMinutes = old;
            widget.onRecovered(updated);
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Recovery timetable generated')),
            );
          },
          icon: const Icon(Icons.auto_fix_high),
          label: const Text('Generate Recovery Timetable'),
        ),
      ],
    );
  }
}

class SmartScheduler {
  static List<StudySession> generate(
    RoutineSettings settings,
    List<SubjectItem> subjects,
  ) {
    if (subjects.isEmpty) return [];

    final wake = _toMinutes(settings.wake);
    final sleep = _toMinutes(settings.sleep);
    final busyStart = _toMinutes(settings.busyStart);
    final busyEnd = _toMinutes(settings.busyEnd);

    final availableBlocks = <List<int>>[];
    if (wake < busyStart) availableBlocks.add([wake, busyStart]);
    if (busyEnd < sleep) availableBlocks.add([busyEnd, sleep]);

    final weighted = <SubjectItem>[];
    final sorted = [...subjects]..sort((a, b) => b.priority.compareTo(a.priority));
    for (final subject in sorted) {
      for (var i = 0; i < subject.priority; i++) {
        weighted.add(subject);
      }
    }

    final sessions = <StudySession>[];
    var subjectIndex = 0;
    var remaining = settings.targetStudyMinutes;

    for (final block in availableBlocks) {
      var cursor = block[0];
      final end = block[1];

      while (remaining > 0 && cursor + settings.sessionMinutes <= end) {
        final duration = settings.sessionMinutes.clamp(30, remaining);
        final subject = weighted[subjectIndex % weighted.length];

        sessions.add(
          StudySession(
            start: _fromMinutes(cursor),
            end: _fromMinutes(cursor + duration),
            subject: subject.name,
            type: 'Focus',
          ),
        );

        cursor += duration;
        remaining -= duration;
        subjectIndex++;

        if (remaining > 0 && cursor + 15 <= end) {
          cursor += 15;
        }
      }
    }

    // Add revision to the final completed timetable if there is room in target.
    if (sessions.length >= 2 && remaining <= 0) {
      final last = sessions.last;
      sessions.add(
        StudySession(
          start: last.end,
          end: _fromMinutes((_toMinutes(last.end) + 15).clamp(0, 1439)),
          subject: 'Quick Revision',
          type: 'Revision',
        ),
      );
    }

    return sessions;
  }
}

int _toMinutes(TimeOfDay time) => time.hour * 60 + time.minute;

TimeOfDay _fromMinutes(int value) {
  final normalized = value % 1440;
  return TimeOfDay(hour: normalized ~/ 60, minute: normalized % 60);
}

int _minutesBetween(TimeOfDay a, TimeOfDay b) {
  var result = _toMinutes(b) - _toMinutes(a);
  if (result < 0) result += 1440;
  return result;
}

String _format(TimeOfDay time) {
  final h = time.hourOfPeriod == 0 ? 12 : time.hourOfPeriod;
  final m = time.minute.toString().padLeft(2, '0');
  return '$h:$m ${time.period == DayPeriod.am ? 'AM' : 'PM'}';
}

IconData _iconForType(String type) {
  switch (type) {
    case 'Revision':
      return Icons.refresh;
    default:
      return Icons.timer_outlined;
  }
}
