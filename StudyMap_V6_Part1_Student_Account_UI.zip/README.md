# StudyMap V6 Part 1 – Student Account UI

## Included
- Professional Welcome screen
- Login screen UI
- Sign Up screen UI
- Password validation
- Forgot Password placeholder
- Google Sign-In placeholder
- Student profile setup
- Class, board and stream selection
- Exam goal selection
- Personalized dashboard
- Logout flow

## Important
This is the UI/prototype stage. Login and Sign Up do NOT create real online accounts yet.
Firebase Authentication, Google Sign-In, password reset and cloud data sync should be added in V6 Part 2.

## Run
flutter pub get
flutter run
