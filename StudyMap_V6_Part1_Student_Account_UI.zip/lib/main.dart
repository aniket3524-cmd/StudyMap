import 'package:flutter/material.dart';

void main() => runApp(const StudyMapApp());

class StudyMapApp extends StatelessWidget {
  const StudyMapApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'StudyMap',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
        scaffoldBackgroundColor: const Color(0xFFF7F8FC),
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
        ),
      ),
      home: const WelcomePage(),
    );
  }
}

class StudentProfile {
  String name;
  String email;
  int schoolClass;
  String board;
  String stream;
  final Set<String> goals;

  StudentProfile({
    required this.name,
    required this.email,
    this.schoolClass = 12,
    this.board = 'CBSE',
    this.stream = 'Humanities',
    Set<String>? goals,
  }) : goals = goals ?? {'Boards'};
}

class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Spacer(),
              Center(
                child: Container(
                  width: 110,
                  height: 110,
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primaryContainer,
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: const Icon(Icons.map, size: 58),
                ),
              ),
              const SizedBox(height: 28),
              const Text(
                'StudyMap',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 36, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              const Text(
                'Plan smarter. Study better. Reach your goal.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 17),
              ),
              const Spacer(),
              FilledButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const LoginPage()),
                  );
                },
                child: const Padding(
                  padding: EdgeInsets.all(14),
                  child: Text('Login'),
                ),
              ),
              const SizedBox(height: 10),
              OutlinedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const SignupPage()),
                  );
                },
                child: const Padding(
                  padding: EdgeInsets.all(14),
                  child: Text('Create Account'),
                ),
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool obscure = true;

  void login() {
    if (email.text.trim().isEmpty || password.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter email and password')),
      );
      return;
    }

    final profile = StudentProfile(
      name: email.text.split('@').first,
      email: email.text.trim(),
    );

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => ProfileSetupPage(profile: profile)),
      (_) => false,
    );
  }

  @override
  void dispose() {
    email.dispose();
    password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          const Text('Welcome Back 👋',
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('Login to continue your StudyMap journey.'),
          const SizedBox(height: 28),
          TextField(
            controller: email,
            keyboardType: TextInputType.emailAddress,
            decoration: const InputDecoration(
              labelText: 'Email',
              prefixIcon: Icon(Icons.email_outlined),
            ),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: password,
            obscureText: obscure,
            decoration: InputDecoration(
              labelText: 'Password',
              prefixIcon: const Icon(Icons.lock_outline),
              suffixIcon: IconButton(
                icon: Icon(obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined),
                onPressed: () => setState(() => obscure = !obscure),
              ),
            ),
          ),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Forgot Password will connect to Firebase in V6 Part 2'),
                  ),
                );
              },
              child: const Text('Forgot Password?'),
            ),
          ),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: login,
            child: const Padding(
              padding: EdgeInsets.all(14),
              child: Text('Login'),
            ),
          ),
          const SizedBox(height: 20),
          const Center(child: Text('OR')),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Google Sign-In will connect to Firebase in Part 2'),
                ),
              );
            },
            icon: const Icon(Icons.g_mobiledata),
            label: const Padding(
              padding: EdgeInsets.all(12),
              child: Text('Continue with Google'),
            ),
          ),
        ],
      ),
    );
  }
}

class SignupPage extends StatefulWidget {
  const SignupPage({super.key});

  @override
  State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  final name = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  final confirmPassword = TextEditingController();
  bool obscure1 = true;
  bool obscure2 = true;

  void signup() {
    if (name.text.trim().isEmpty ||
        email.text.trim().isEmpty ||
        password.text.isEmpty ||
        confirmPassword.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill all details')),
      );
      return;
    }

    if (!email.text.contains('@')) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a valid email')),
      );
      return;
    }

    if (password.text.length < 6) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Password must be at least 6 characters')),
      );
      return;
    }

    if (password.text != confirmPassword.text) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Passwords do not match')),
      );
      return;
    }

    final profile = StudentProfile(
      name: name.text.trim(),
      email: email.text.trim(),
    );

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => ProfileSetupPage(profile: profile)),
    );
  }

  @override
  void dispose() {
    name.dispose();
    email.dispose();
    password.dispose();
    confirmPassword.dispose();
    super.dispose();
  }

  Widget passwordField(
    TextEditingController controller,
    String label,
    bool obscure,
    VoidCallback toggle,
  ) {
    return TextField(
      controller: controller,
      obscureText: obscure,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: const Icon(Icons.lock_outline),
        suffixIcon: IconButton(
          icon: Icon(obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined),
          onPressed: toggle,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          const Text('Create Account 🚀',
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('Start building your personal study roadmap.'),
          const SizedBox(height: 26),
          TextField(
            controller: name,
            decoration: const InputDecoration(
              labelText: 'Full Name',
              prefixIcon: Icon(Icons.person_outline),
            ),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: email,
            keyboardType: TextInputType.emailAddress,
            decoration: const InputDecoration(
              labelText: 'Email',
              prefixIcon: Icon(Icons.email_outlined),
            ),
          ),
          const SizedBox(height: 14),
          passwordField(
            password,
            'Password',
            obscure1,
            () => setState(() => obscure1 = !obscure1),
          ),
          const SizedBox(height: 14),
          passwordField(
            confirmPassword,
            'Confirm Password',
            obscure2,
            () => setState(() => obscure2 = !obscure2),
          ),
          const SizedBox(height: 24),
          FilledButton(
            onPressed: signup,
            child: const Padding(
              padding: EdgeInsets.all(14),
              child: Text('Create My Account'),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Prototype UI: Real account creation and secure authentication will be added with Firebase in V6 Part 2.',
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

class ProfileSetupPage extends StatefulWidget {
  const ProfileSetupPage({super.key, required this.profile});
  final StudentProfile profile;

  @override
  State<ProfileSetupPage> createState() => _ProfileSetupPageState();
}

class _ProfileSetupPageState extends State<ProfileSetupPage> {
  final boards = const ['CBSE', 'Bihar Board', 'ICSE', 'Other'];
  final streams = const ['Science', 'Commerce', 'Humanities'];
  final goals = const ['Boards', 'JEE', 'NEET', 'CUET', 'CLAT'];

  void finish() {
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(
        builder: (_) => StudentDashboard(profile: widget.profile),
      ),
      (_) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.profile;

    return Scaffold(
      appBar: AppBar(title: const Text('Profile Setup')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          const Text('Tell us about your studies 📚',
              style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text('Hi ${p.name}, this helps StudyMap personalize your roadmap.'),
          const SizedBox(height: 22),
          const Text('Class', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: List.generate(
              12,
              (index) => ChoiceChip(
                label: Text('Class ${index + 1}'),
                selected: p.schoolClass == index + 1,
                onSelected: (_) => setState(() => p.schoolClass = index + 1),
              ),
            ),
          ),
          const SizedBox(height: 20),
          DropdownButtonFormField<String>(
            value: p.board,
            decoration: const InputDecoration(
              labelText: 'Board',
              prefixIcon: Icon(Icons.school_outlined),
            ),
            items: boards
                .map((b) => DropdownMenuItem(value: b, child: Text(b)))
                .toList(),
            onChanged: (v) => setState(() => p.board = v!),
          ),
          if (p.schoolClass >= 11) ...[
            const SizedBox(height: 20),
            const Text('Stream', style: TextStyle(fontWeight: FontWeight.bold)),
            ...streams.map(
              (stream) => RadioListTile<String>(
                value: stream,
                groupValue: p.stream,
                title: Text(stream),
                onChanged: (v) => setState(() => p.stream = v!),
              ),
            ),
          ],
          const SizedBox(height: 16),
          const Text('Your Goals 🎯',
              style: TextStyle(fontWeight: FontWeight.bold)),
          ...goals.map(
            (goal) => CheckboxListTile(
              value: p.goals.contains(goal),
              title: Text(goal),
              onChanged: (v) => setState(() {
                if (v == true) {
                  p.goals.add(goal);
                } else {
                  p.goals.remove(goal);
                }
              }),
            ),
          ),
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: finish,
            icon: const Icon(Icons.arrow_forward),
            label: const Padding(
              padding: EdgeInsets.all(14),
              child: Text('Continue to StudyMap'),
            ),
          ),
        ],
      ),
    );
  }
}

class StudentDashboard extends StatelessWidget {
  const StudentDashboard({super.key, required this.profile});
  final StudentProfile profile;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('StudyMap'),
        actions: [
          IconButton(
            tooltip: 'Logout',
            icon: const Icon(Icons.logout),
            onPressed: () {
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const WelcomePage()),
                (_) => false,
              );
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            'Hello, ${profile.name} 👋',
            style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 6),
          Text(
            'Class ${profile.schoolClass} • ${profile.board}'
            '${profile.schoolClass >= 11 ? ' • ${profile.stream}' : ''}',
          ),
          const SizedBox(height: 18),
          Card(
            child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.flag_outlined)),
              title: const Text('Your Goals'),
              subtitle: Text(profile.goals.isEmpty
                  ? 'No goals selected'
                  : profile.goals.join(', ')),
            ),
          ),
          const SizedBox(height: 12),
          const Text('Account Status',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          Card(
            child: const ListTile(
              leading: Icon(Icons.cloud_off_outlined),
              title: Text('Local Prototype Account'),
              subtitle: Text(
                'Firebase Authentication and cloud sync will be connected in V6 Part 2.',
              ),
            ),
          ),
          const SizedBox(height: 20),
          const Text('StudyMap Features',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const _FeatureTile(
            icon: Icons.map_outlined,
            title: 'Smart Roadmap',
            subtitle: 'Plan your syllabus and exam targets',
          ),
          const _FeatureTile(
            icon: Icons.calendar_month_outlined,
            title: 'Smart Timetable',
            subtitle: 'Generate your daily study schedule',
          ),
          const _FeatureTile(
            icon: Icons.cloud_outlined,
            title: 'Cloud Sync',
            subtitle: 'Coming in V6 Part 2',
          ),
        ],
      ),
    );
  }
}

class _FeatureTile extends StatelessWidget {
  const _FeatureTile({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Icon(icon),
        title: Text(title),
        subtitle: Text(subtitle),
      ),
    );
  }
}
