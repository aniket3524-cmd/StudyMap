package com.studymap;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;

/**
 * Minimal, crash-safe AccessibilityService for StudyMap Focus Lock.
 * The first V3 build intentionally does not run blocking logic; it verifies
 * that HyperOS can successfully bind the service.
 */
public class StudyMapAccessibilityService extends AccessibilityService {
    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Intentionally empty for the service-binding test build.
    }

    @Override
    public void onInterrupt() {
        // Nothing to interrupt.
    }
}
