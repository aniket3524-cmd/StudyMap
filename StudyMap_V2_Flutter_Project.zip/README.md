# StudyMap V2

## New in V2
- Welcome onboarding
- Student name
- Class 1–12 selection
- Stream selection for Class 11–12
- Multiple exam goals: Boards, JEE, NEET, CUET, CLAT
- Profile saved locally with SharedPreferences

## Existing features
- Study tasks
- Focus timer
- Study Rescue Mode
- Progress screen

## Important
This ZIP contains source code. To run it you need a Flutter development environment.
