import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const StudyMapApp());

class StudentProfile {
  String name;
  int schoolClass;
  String? stream;
  List<String> goals;
  StudentProfile({required this.name, required this.schoolClass, this.stream, required this.goals});
}

class StudyMapApp extends StatefulWidget {
  const StudyMapApp({super.key});
  @override
  State<StudyMapApp> createState() => _StudyMapAppState();
}

class _StudyMapAppState extends State<StudyMapApp> {
  StudentProfile? profile;
  bool loading = true;

  @override
  void initState() { super.initState(); loadProfile(); }

  Future<void> loadProfile() async {
    final p = await SharedPreferences.getInstance();
    final name = p.getString('name');
    if (name != null) {
      setState(() {
        profile = StudentProfile(
          name: name,
          schoolClass: p.getInt('class') ?? 12,
          stream: p.getString('stream'),
          goals: p.getStringList('goals') ?? [],
        );
        loading = false;
      });
    } else {
      setState(() => loading = false);
    }
  }

  Future<void> saveProfile(StudentProfile value) async {
    final p = await SharedPreferences.getInstance();
    await p.setString('name', value.name);
    await p.setInt('class', value.schoolClass);
    if (value.stream != null) await p.setString('stream', value.stream!);
    else await p.remove('stream');
    await p.setStringList('goals', value.goals);
    setState(() => profile = value);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'StudyMap',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
        scaffoldBackgroundColor: const Color(0xFFF7F8FC),
      ),
      home: loading
          ? const Scaffold(body: Center(child: CircularProgressIndicator()))
          : profile == null
              ? WelcomeFlow(onComplete: saveProfile)
              : AppShell(profile: profile!, onProfileChanged: saveProfile),
    );
  }
}

class WelcomeFlow extends StatefulWidget {
  const WelcomeFlow({super.key, required this.onComplete});
  final ValueChanged<StudentProfile> onComplete;
  @override
  State<WelcomeFlow> createState() => _WelcomeFlowState();
}

class _WelcomeFlowState extends State<WelcomeFlow> {
  int step = 0;
  final nameController = TextEditingController();
  int selectedClass = 12;
  String? stream;
  final goals = <String>{};

  final goalOptions = const ['Boards', 'JEE', 'NEET', 'CUET', 'CLAT', 'School Exams'];

  @override
  void dispose() { nameController.dispose(); super.dispose(); }

  void next() {
    if (step == 0 && nameController.text.trim().isEmpty) return;
    if (step == 2 && (selectedClass == 11 || selectedClass == 12) && stream == null) return;
    if (step == 3 && goals.isEmpty) return;
    if (step == 3) {
      widget.onComplete(StudentProfile(
        name: nameController.text.trim(),
        schoolClass: selectedClass,
        stream: (selectedClass == 11 || selectedClass == 12) ? stream : null,
        goals: goals.toList(),
      ));
    } else {
      setState(() => step++);
    }
  }

  @override
  Widget build(BuildContext context) {
    final titles = ['Welcome to StudyMap', 'Choose Your Class', 'Choose Your Stream', 'Your Study Goals'];
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              LinearProgressIndicator(value: (step + 1) / 4, borderRadius: BorderRadius.circular(8)),
              const SizedBox(height: 32),
              Text(titles[step], style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text(step == 0 ? 'Don’t Restart. Recover. Let’s build your personal study journey.'
                  : 'StudyMap will personalize your roadmap based on your choices.'),
              const SizedBox(height: 28),
              Expanded(child: _stepContent()),
              Row(children: [
                if (step > 0)
                  TextButton(onPressed: () => setState(() => step--), child: const Text('Back')),
                const Spacer(),
                FilledButton(
                  onPressed: next,
                  child: Text(step == 3 ? 'Start My Journey' : 'Continue'),
                ),
              ]),
            ],
          ),
        ),
      ),
    );
  }

  Widget _stepContent() {
    if (step == 0) {
      return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('What should we call you?', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
        const SizedBox(height: 12),
        TextField(controller: nameController, decoration: const InputDecoration(
          labelText: 'Your Name', border: OutlineInputBorder(), prefixIcon: Icon(Icons.person))),
        const SizedBox(height: 24),
        const Card(child: Padding(padding: EdgeInsets.all(16), child: Text(
          'StudyMap helps you plan, focus, track progress and recover when you fall behind.'))),
      ]);
    }
    if (step == 1) {
      return GridView.count(
        crossAxisCount: 3,
        childAspectRatio: 1.25,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        children: List.generate(12, (i) {
          final c = i + 1;
          final selected = selectedClass == c;
          return InkWell(
            onTap: () => setState(() => selectedClass = c),
            child: Card(
              color: selected ? Theme.of(context).colorScheme.primaryContainer : null,
              child: Center(child: Text('Class $c', style: const TextStyle(fontWeight: FontWeight.bold))),
            ),
          );
        }),
      );
    }
    if (step == 2) {
      if (selectedClass != 11 && selectedClass != 12) {
        return const Center(child: Text('Stream selection is needed only for Class 11 and 12.\nTap Continue.',
          textAlign: TextAlign.center, style: TextStyle(fontSize: 18)));
      }
      return Column(children: ['Science', 'Commerce', 'Humanities'].map((s) =>
        Card(child: RadioListTile<String>(
          value: s, groupValue: stream, title: Text(s),
          subtitle: Text(s == 'Science' ? 'PCM / PCB and related subjects' :
            s == 'Commerce' ? 'Accounts, Business, Economics and more' :
            'History, Political Science, Geography and more'),
          onChanged: (v) => setState(() => stream = v),
        ))).toList());
    }
    return ListView(children: [
      const Text('You can select multiple goals.', style: TextStyle(fontSize: 16)),
      const SizedBox(height: 12),
      ...goalOptions.map((g) => Card(child: CheckboxListTile(
        value: goals.contains(g), title: Text(g),
        onChanged: (v) => setState(() => v == true ? goals.add(g) : goals.remove(g)),
      ))),
    ]);
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key, required this.profile, required this.onProfileChanged});
  final StudentProfile profile;
  final ValueChanged<StudentProfile> onProfileChanged;
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int index = 0;
  final tasks = <StudyTask>[
    StudyTask('Welcome Task', 'Create your first study plan', 20),
    StudyTask('Focus', 'Complete one important topic', 45),
  ];

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(profile: widget.profile, tasks: tasks, refresh: () => setState(() {})),
      PlannerPage(tasks: tasks, refresh: () => setState(() {})),
      const RescuePage(),
      ProgressPage(tasks: tasks),
      ProfilePage(profile: widget.profile, onSave: widget.onProfileChanged),
    ];
    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.map_outlined), selectedIcon: Icon(Icons.map), label: 'Plan'),
          NavigationDestination(icon: Icon(Icons.health_and_safety_outlined), selectedIcon: Icon(Icons.health_and_safety), label: 'Rescue'),
          NavigationDestination(icon: Icon(Icons.bar_chart_outlined), selectedIcon: Icon(Icons.bar_chart), label: 'Progress'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class StudyTask {
  StudyTask(this.subject, this.title, this.minutes, {this.done = false});
  final String subject;
  final String title;
  final int minutes;
  bool done;
}

class HomePage extends StatelessWidget {
  const HomePage({super.key, required this.profile, required this.tasks, required this.refresh});
  final StudentProfile profile;
  final List<StudyTask> tasks;
  final VoidCallback refresh;

  @override
  Widget build(BuildContext context) {
    final done = tasks.where((t) => t.done).length;
    final progress = tasks.isEmpty ? 0.0 : done / tasks.length;
    return ListView(padding: const EdgeInsets.all(20), children: [
      Text('Good Evening, ${profile.name} 👋', style: const TextStyle(fontSize: 17)),
      const SizedBox(height: 4),
      const Text('Your StudyMap', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
      const SizedBox(height: 18),
      Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Class ${profile.schoolClass}${profile.stream == null ? '' : ' • ${profile.stream}'}',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Text('Goals: ${profile.goals.join(', ')}'),
      ]))),
      const SizedBox(height: 12),
      Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Today’s Progress', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        const SizedBox(height: 12),
        LinearProgressIndicator(value: progress, minHeight: 10, borderRadius: BorderRadius.circular(10)),
        const SizedBox(height: 8),
        Text('$done of ${tasks.length} tasks completed'),
      ]))),
      const SizedBox(height: 18),
      const Text('Today’s Tasks', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      ...tasks.map((t) => Card(child: CheckboxListTile(
        value: t.done,
        title: Text(t.title),
        subtitle: Text('${t.subject} • ${t.minutes} min'),
        onChanged: (v) { t.done = v ?? false; refresh(); },
      ))),
      const SizedBox(height: 14),
      const FocusTimer(),
    ]);
  }
}

class PlannerPage extends StatefulWidget {
  const PlannerPage({super.key, required this.tasks, required this.refresh});
  final List<StudyTask> tasks;
  final VoidCallback refresh;
  @override
  State<PlannerPage> createState() => _PlannerPageState();
}

class _PlannerPageState extends State<PlannerPage> {
  void addTask() {
    final subject = TextEditingController();
    final title = TextEditingController();
    final mins = TextEditingController(text: '30');
    showModalBottomSheet(context: context, isScrollControlled: true, builder: (context) =>
      Padding(
        padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(context).viewInsets.bottom + 20),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Add Study Task', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          TextField(controller: subject, decoration: const InputDecoration(labelText: 'Subject')),
          TextField(controller: title, decoration: const InputDecoration(labelText: 'Topic / Task')),
          TextField(controller: mins, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Minutes')),
          const SizedBox(height: 12),
          FilledButton(onPressed: () {
            if (subject.text.trim().isEmpty || title.text.trim().isEmpty) return;
            setState(() => widget.tasks.add(StudyTask(subject.text.trim(), title.text.trim(), int.tryParse(mins.text) ?? 30)));
            widget.refresh();
            Navigator.pop(context);
          }, child: const Text('Save Task')),
        ]),
      ));
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('Study Roadmap 🗺️', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    const Text('Build your personal daily study plan.'),
    const SizedBox(height: 16),
    ...widget.tasks.map((t) => Card(child: ListTile(
      leading: const Icon(Icons.menu_book_outlined),
      title: Text(t.title),
      subtitle: Text(t.subject),
      trailing: Text('${t.minutes}m'),
    ))),
    const SizedBox(height: 12),
    FilledButton.icon(onPressed: addTask, icon: const Icon(Icons.add), label: const Text('Add Study Task')),
  ]);
}

class RescuePage extends StatefulWidget {
  const RescuePage({super.key});
  @override
  State<RescuePage> createState() => _RescuePageState();
}
class _RescuePageState extends State<RescuePage> {
  double missed = 3, hours = 4;
  @override
  Widget build(BuildContext context) {
    final tasks = (missed * 2 / hours).ceil().clamp(1, 8);
    return ListView(padding: const EdgeInsets.all(20), children: [
      const Text('Study Rescue 🆘', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Don’t Restart. Recover.'),
      const SizedBox(height: 24),
      Text('Missed study days: ${missed.round()}'),
      Slider(value: missed, min: 1, max: 30, divisions: 29, onChanged: (v) => setState(() => missed = v)),
      Text('Available hours/day: ${hours.round()}'),
      Slider(value: hours, min: 1, max: 12, divisions: 11, onChanged: (v) => setState(() => hours = v)),
      Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Recovery Plan', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        Text('Day 1: $tasks priority tasks'),
        Text('Day 2: $tasks priority tasks + revision'),
        const Text('Day 3: Light revision + practice'),
        const SizedBox(height: 8),
        const Text('Small steps. Back on track.', style: TextStyle(fontWeight: FontWeight.w600)),
      ]))),
    ]);
  }
}

class ProgressPage extends StatelessWidget {
  const ProgressPage({super.key, required this.tasks});
  final List<StudyTask> tasks;
  @override
  Widget build(BuildContext context) {
    final done = tasks.where((e) => e.done).length;
    return ListView(padding: const EdgeInsets.all(20), children: [
      const Text('Progress 📊', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
      const SizedBox(height: 18),
      _card('Completed Tasks', '$done / ${tasks.length}'),
      _card('Study Streak', '7 Days 🔥'),
      _card('This Week', 'Focus more to unlock analytics'),
      _card('Exam Readiness', 'Coming soon'),
    ]);
  }
  Widget _card(String a, String b) => Card(child: ListTile(title: Text(a), trailing: Text(b, style: const TextStyle(fontWeight: FontWeight.bold))));
}

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key, required this.profile, required this.onSave});
  final StudentProfile profile;
  final ValueChanged<StudentProfile> onSave;
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}
class _ProfilePageState extends State<ProfilePage> {
  late TextEditingController name;
  @override
  void initState() { super.initState(); name = TextEditingController(text: widget.profile.name); }
  @override
  void dispose() { name.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const Center(child: CircleAvatar(radius: 42, child: Icon(Icons.person, size: 44))),
    const SizedBox(height: 12),
    const Center(child: Text('Student Profile', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold))),
    const SizedBox(height: 24),
    TextField(controller: name, decoration: const InputDecoration(labelText: 'Name', border: OutlineInputBorder())),
    const SizedBox(height: 14),
    ListTile(leading: const Icon(Icons.school), title: const Text('Class'), trailing: Text('Class ${widget.profile.schoolClass}')),
    if (widget.profile.stream != null) ListTile(leading: const Icon(Icons.account_tree), title: const Text('Stream'), trailing: Text(widget.profile.stream!)),
    ListTile(leading: const Icon(Icons.flag_outlined), title: const Text('Goals'), subtitle: Text(widget.profile.goals.join(', '))),
    const SizedBox(height: 12),
    FilledButton(onPressed: () {
      widget.profile.name = name.text.trim().isEmpty ? widget.profile.name : name.text.trim();
      widget.onSave(widget.profile);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Profile saved successfully')));
    }, child: const Text('Save Profile')),
  ]);
}

class FocusTimer extends StatefulWidget {
  const FocusTimer({super.key});
  @override
  State<FocusTimer> createState() => _FocusTimerState();
}
class _FocusTimerState extends State<FocusTimer> {
  int seconds = 25 * 60;
  Timer? timer;
  bool running = false;
  void toggle() {
    if (running) {
      timer?.cancel();
      setState(() => running = false);
    } else {
      setState(() => running = true);
      timer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (seconds <= 0) {
          timer?.cancel();
          setState(() => running = false);
        } else {
          setState(() => seconds--);
        }
      });
    }
  }
  @override
  void dispose() { timer?.cancel(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    final m = (seconds ~/ 60).toString().padLeft(2, '0');
    final s = (seconds % 60).toString().padLeft(2, '0');
    return Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
      const Text('Focus Timer ⏱️', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      Text('$m:$s', style: const TextStyle(fontSize: 40, fontWeight: FontWeight.bold)),
      FilledButton(onPressed: toggle, child: Text(running ? 'Pause' : 'Start Focus')),
    ])));
  }
}
